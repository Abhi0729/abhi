# BTP Cloud Foundry Deployment Guide

## Files Created

| File | Purpose |
|------|---------|
| `manifest.yml` | CF manifest for direct `cf push` deployment |
| `mta.yaml` | MTA descriptor for `mbt build` + `cf deploy` |
| `deploy-cf.sh` | Automated deployment script |
| `backend/Procfile` | Process definition for backend |
| `backend/runtime.txt` | Python version specification |
| `frontend/Staticfile` | Static file buildpack config |
| `frontend/nginx.conf` | Nginx proxy configuration |

## Option 1: Simple CF Push (Recommended for Quick Deploy)

### Prerequisites
- Cloud Foundry CLI installed
- Logged into BTP CF: `cf login -a https://api.cf.us10.hana.ondemand.com`

### Steps

1. **Update manifest.yml routes** with your actual CF domain:
   ```yaml
   routes:
     - route: rpt-inventory-backend.cfapps.<region>.hana.ondemand.com
   ```

2. **Build frontend**:
   ```bash
   cd frontend
   npm install
   npm run build
   cd ..
   ```

3. **Initialize database**:
   ```bash
   cd backend
   python seed.py
   cd ..
   ```

4. **Deploy**:
   ```bash
   cf push
   ```

5. **Set AI Core environment variables** (optional):
   ```bash
   cf set-env rpt-inventory-backend AICORE_AUTH_URL "https://xxx.authentication.sap.hana.ondemand.com"
   cf set-env rpt-inventory-backend AICORE_CLIENT_ID "your-client-id"
   cf set-env rpt-inventory-backend AICORE_CLIENT_SECRET "your-secret"
   cf set-env rpt-inventory-backend AICORE_BASE_URL "https://api.ai.prod.xxx.aws.ml.hana.ondemand.com"
   cf set-env rpt-inventory-backend AICORE_RESOURCE_GROUP "default"
   cf set-env rpt-inventory-backend RPT_DEPLOYMENT_ID "your-rpt-deployment-id"
   cf set-env rpt-inventory-backend GPT_DEPLOYMENT_ID "your-gpt-deployment-id"
   cf restage rpt-inventory-backend
   ```

## Option 2: MTA Deployment

### Prerequisites
- MTA Build Tool: `npm install -g mbt`
- CF CLI with MTA plugin: `cf install-plugin multiapps`

### Steps

1. **Build MTA archive**:
   ```bash
   mbt build
   ```

2. **Deploy**:
   ```bash
   cf deploy mta_archives/rpt-inventory-intelligence_1.0.0.mtar
   ```

## Option 3: Automated Script

```bash
# Update CF_ORG and CF_SPACE in the script first
./deploy-cf.sh
```

## Post-Deployment

### Verify Deployment
```bash
# Check app status
cf apps

# Check logs
cf logs rpt-inventory-backend --recent
cf logs rpt-inventory-frontend --recent

# Test health endpoint
curl https://rpt-inventory-backend.cfapps.<region>.hana.ondemand.com/api/health
```

### URLs
- **Frontend**: `https://rpt-inventory-frontend.cfapps.<region>.hana.ondemand.com`
- **Backend API**: `https://rpt-inventory-backend.cfapps.<region>.hana.ondemand.com`
- **API Docs**: `https://rpt-inventory-backend.cfapps.<region>.hana.ondemand.com/docs`

## Troubleshooting

### Frontend can't reach backend
Update `frontend/src/api.js` to use absolute URL:
```javascript
const API_BASE = 'https://rpt-inventory-backend.cfapps.<region>.hana.ondemand.com/api';
```

### Database not persisting
CF app instances are ephemeral. For production, use a persistent database service:
```bash
cf create-service postgresql-db trial rpt-db
cf bind-service rpt-inventory-backend rpt-db
```

### AI Core not working
Ensure credentials are set correctly and AI Core service is bound or environment variables are configured.
