#!/bin/bash
# BTP Cloud Foundry Deployment Script
# Physical Inventory Intelligence

set -e

echo "=========================================="
echo "  Physical Inventory Intelligence"
echo "  BTP Cloud Foundry Deployment"
echo "=========================================="

# Configuration - Update these values
CF_API="https://api.cf.us10.hana.ondemand.com"
CF_ORG="your-org-name"
CF_SPACE="your-space-name"
BACKEND_ROUTE="rpt-inventory-backend"
FRONTEND_ROUTE="rpt-inventory-frontend"
DOMAIN="cfapps.us10.hana.ondemand.com"

# Check if cf CLI is installed
if ! command -v cf &> /dev/null; then
    echo "Error: Cloud Foundry CLI not installed"
    echo "Install from: https://github.com/cloudfoundry/cli"
    exit 1
fi

# Login check
echo ""
echo "Step 1: Checking Cloud Foundry login..."
if ! cf target &> /dev/null; then
    echo "Not logged in. Please login:"
    cf login -a $CF_API
fi

# Set target
echo ""
echo "Step 2: Setting target org/space..."
cf target -o "$CF_ORG" -s "$CF_SPACE" || {
    echo "Please update CF_ORG and CF_SPACE in this script"
    exit 1
}

# Build frontend
echo ""
echo "Step 3: Building frontend..."
cd frontend
npm install
npm run build
cd ..

# Initialize backend database
echo ""
echo "Step 4: Initializing backend database..."
cd backend
if [ ! -f "inventory.db" ]; then
    echo "Creating database with seed data..."
    python seed.py
fi
cd ..

# Deploy backend
echo ""
echo "Step 5: Deploying backend..."
cf push rpt-inventory-backend -f manifest.yml --no-start

# Set environment variables for backend (if needed)
echo ""
echo "Step 6: Configuring backend environment..."
# Uncomment and update these if you have AI Core credentials
# cf set-env rpt-inventory-backend AICORE_AUTH_URL "https://xxx.authentication.sap.hana.ondemand.com"
# cf set-env rpt-inventory-backend AICORE_CLIENT_ID "your-client-id"
# cf set-env rpt-inventory-backend AICORE_CLIENT_SECRET "your-client-secret"
# cf set-env rpt-inventory-backend AICORE_BASE_URL "https://api.ai.prod.xxx.aws.ml.hana.ondemand.com"
# cf set-env rpt-inventory-backend AICORE_RESOURCE_GROUP "default"
# cf set-env rpt-inventory-backend RPT_DEPLOYMENT_ID "your-rpt-deployment-id"
# cf set-env rpt-inventory-backend GPT_DEPLOYMENT_ID "your-gpt-deployment-id"

# Start backend
echo ""
echo "Step 7: Starting backend..."
cf start rpt-inventory-backend

# Deploy frontend
echo ""
echo "Step 8: Deploying frontend..."
cf push rpt-inventory-frontend -f manifest.yml

echo ""
echo "=========================================="
echo "  Deployment Complete!"
echo "=========================================="
echo ""
echo "Backend:  https://${BACKEND_ROUTE}.${DOMAIN}"
echo "Frontend: https://${FRONTEND_ROUTE}.${DOMAIN}"
echo ""
echo "API Health: https://${BACKEND_ROUTE}.${DOMAIN}/api/health"
echo ""
