# Physical Inventory Intelligence

A full-stack demo application that demonstrates how **SAP-RPT** (SAP's Relational Pretrained Transformer) can be used for zero-shot classification and regression to prioritize physical inventory recounts in a warehouse setting.

## Overview

This application shows how physical inventory count documents (PIDs) from two mock SAP ERP sources (ECC and S/4HANA) are:
1. **Unified** into a common data model
2. **Analyzed** to compute variance patterns and trends
3. **Scored** by SAP-RPT via the SAP Generative AI Hub SDK
4. **Ranked** into a prioritized recount list for warehouse teams

### Key Features

- **Zero-shot predictions**: SAP-RPT performs classification (HIGH/MEDIUM/LOW priority) and regression (0-100 urgency score) without any training or fine-tuning
- **Demo-safe fallback**: Runs fully in mock mode when AI Core credentials are unavailable
- **Real-time dashboard**: React frontend with filtering, sorting, and detailed SKU views
- **Synthetic data**: Reproducible dataset with realistic variance patterns

## Tech Stack

- **Backend**: Python 3.11+, FastAPI, SQLite, Pandas
- **AI Integration**: `generative-ai-hub-sdk` for SAP-RPT calls
- **Frontend**: React 18, Vite, Recharts

## Quick Start

### Prerequisites

- Python 3.11+
- Node.js 18+
- npm or yarn

### One-Command Startup

```bash
cd retail-usecase/rpt-inventory-intelligence
./start.sh
```

This single command will:
1. Create Python virtual environment
2. Install backend dependencies
3. Generate synthetic data (120 SKUs, 60 days of history)
4. Install frontend dependencies
5. Start both backend and frontend

Access the application at **http://localhost:5173**

Press `Ctrl+C` to stop all services.

### Manual Setup (Alternative)

<details>
<summary>Click to expand manual setup instructions</summary>

#### 1. Setup Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python seed.py
uvicorn app.main:app --reload
```

#### 2. Setup Frontend (separate terminal)

```bash
cd frontend
npm install
npm run dev
```

</details>

## Configuration

### Running Without AI Core (Mock Mode)

The application runs fully in **mock mode** without any configuration. The mock scorer uses simple heuristics to mimic SAP-RPT's output, making it perfect for:
- Offline demos
- Development without AI Core access
- Testing the UI/UX

### Connecting to SAP AI Core

To use real SAP-RPT predictions, you need:
1. An SAP BTP account with AI Core service
2. Generative AI Hub enabled in your AI Core instance
3. An SAP-RPT model deployed in AI Launchpad

#### Option 1: Service Key JSON

1. In BTP Cockpit, navigate to your AI Core service instance
2. Create a service key
3. Download the JSON file
4. Set the path in `.env`:

```env
AICORE_SERVICE_KEY_PATH=/path/to/service-key.json
```

#### Option 2: Environment Variables

```env
AICORE_AUTH_URL=https://xxx.authentication.sap.hana.ondemand.com
AICORE_CLIENT_ID=your-client-id
AICORE_CLIENT_SECRET=your-client-secret
AICORE_BASE_URL=https://api.ai.prod.xxx.aws.ml.hana.ondemand.com/v2
AICORE_RESOURCE_GROUP=default
RPT_DEPLOYMENT_ID=your-deployment-id
```

### Where to Find Credentials

| Value | Location |
|-------|----------|
| Auth URL, Client ID/Secret, Base URL | BTP Cockpit → AI Core Instance → Service Keys |
| Resource Group | AI Launchpad → Configuration (usually "default") |
| Deployment ID | AI Launchpad → Deploy → SAP-RPT model → Copy deployment ID |

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Health check, shows if running in live or mock mode |
| `/api/kpis` | GET | Aggregate KPIs for dashboard |
| `/api/skus` | GET | List SKUs with predictions (supports filtering) |
| `/api/skus/{sku_id}` | GET | Detailed SKU info with 60-day history |
| `/api/skus/categories` | GET | List of all categories |
| `/api/recounts/rescore` | POST | Trigger fresh pattern calculation and RPT scoring |

## Data Model

### SKU Master
- 120 SKUs across 5 categories (Electronics, Apparel, Grocery, Hardware, Home & Garden)
- Split between ECC and S/4HANA source systems

### PID Documents
- 60 days of physical inventory count history
- 1-4 counts per SKU per week
- Variance patterns:
  - ~80% normal (±3% variance)
  - ~12% worsening drift (variance grows to 15-20%)
  - ~8% sporadic anomalies (isolated large variances)

### Daily Count Pattern (Features for RPT)
- `avg_variance_pct`: 14-day trailing mean variance
- `recount_frequency_7d`: Count of PIDs in trailing 7 days
- `days_since_last_count`: Days since most recent PID
- `variance_trend`: worsening/stable/improving

## SAP-RPT Integration

SAP-RPT is called with these parameters:

```python
{
    "prediction_config": {
        "target_columns": [
            {"name": "recount_priority", "task_type": "classification"},
            {"name": "urgency_score", "task_type": "regression"}
        ]
    },
    "columns": {
        "SKU_ID": [...],
        "CATEGORY": [...],
        "AVG_VARIANCE_PCT": [...],
        "RECOUNT_FREQUENCY_7D": [...],
        "DAYS_SINCE_LAST_COUNT": [...],
        "VARIANCE_TREND": [...],
        "recount_priority": ["[PREDICT]", ...],
        "urgency_score": ["[PREDICT]", ...]
    }
}
```

## Known Limitations

1. **Synthetic data only** - This is a demo application; no real SAP system integration
2. **Mock scorer is heuristic** - Not a trained model, uses simple rules for demo purposes
3. **SAP-RPT request limits** - 512 rows / 10 columns per request; large SKU counts are chunked automatically
4. **No authentication** - This demo has no user authentication; add your own for production use

## Project Structure

```
rpt-inventory-intelligence/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI app
│   │   ├── config.py            # AI Core credential handling
│   │   ├── db.py                # SQLite setup
│   │   ├── models.py            # Pydantic models
│   │   ├── data_generator.py    # Synthetic data generation
│   │   ├── pattern_engine.py    # Variance pattern calculations
│   │   ├── rpt_client.py        # SAP-RPT + mock fallback
│   │   └── routers/             # API endpoints
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.jsx              # Main app component
│   │   ├── api.js               # API client
│   │   ├── theme.css            # Styling
│   │   └── components/          # React components
│   ├── package.json
│   └── vite.config.js
├── docker-compose.yml
└── README.md
```

## Docker

```bash
docker-compose up --build
```

Access the application at http://localhost:5173

## License

This is a demo application for educational purposes.
