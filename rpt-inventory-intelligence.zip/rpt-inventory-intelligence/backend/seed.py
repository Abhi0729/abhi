#!/usr/bin/env python3
"""
Seed script for Physical Inventory Intelligence.

Generates synthetic data and initializes the database.
Run: python seed.py
"""
import sys
from pathlib import Path

# Add app to path
sys.path.insert(0, str(Path(__file__).parent))

from app.db import init_db, clear_db
from app.data_generator import generate_all_data
from app.pattern_engine import refresh_patterns
from app.rpt_client import predict_recount_priorities, save_predictions_to_cache
from app.pattern_engine import get_sku_patterns_with_master


def main():
    print("=" * 60)
    print("Physical Inventory Intelligence - Data Seeding")
    print("=" * 60)

    # Initialize database
    print("\n📦 Initializing database...")
    init_db()

    # Clear existing data
    print("🗑️  Clearing existing data...")
    clear_db()

    # Generate synthetic data
    print("\n🏭 Generating synthetic data...")
    generate_all_data(export_csv=True)

    # Compute patterns
    print("\n📊 Computing pattern metrics...")
    refresh_patterns()

    # Generate initial predictions
    print("\n🤖 Generating initial predictions...")
    features_df = get_sku_patterns_with_master()
    if not features_df.empty:
        predictions_df, is_mock, duration_ms = predict_recount_priorities(features_df)
        save_predictions_to_cache(predictions_df, is_mock)

        mode = "mock scorer" if is_mock else "SAP-RPT"
        print(f"   Generated {len(predictions_df)} predictions using {mode} in {duration_ms:.1f}ms")

        # Summary stats
        high = len(predictions_df[predictions_df['recount_priority'] == 'HIGH'])
        med = len(predictions_df[predictions_df['recount_priority'] == 'MEDIUM'])
        low = len(predictions_df[predictions_df['recount_priority'] == 'LOW'])
        print(f"   Priority distribution: HIGH={high}, MEDIUM={med}, LOW={low}")

    print("\n" + "=" * 60)
    print("✅ Seeding complete!")
    print("=" * 60)
    print("\nTo start the backend:")
    print("  cd backend && uvicorn app.main:app --reload")
    print("\nTo start the frontend:")
    print("  cd frontend && npm run dev")


if __name__ == "__main__":
    main()
