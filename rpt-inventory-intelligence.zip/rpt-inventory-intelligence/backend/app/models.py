"""Pydantic models for API requests and responses."""
from pydantic import BaseModel, Field
from typing import Optional, List, Literal
from datetime import date, datetime


# Enums as Literals for type safety
PriorityLevel = Literal["HIGH", "MEDIUM", "LOW"]
SourceSystem = Literal["ECC", "S4HANA"]
VarianceTrend = Literal["worsening", "stable", "improving"]
Category = Literal["Electronics", "Apparel", "Grocery", "Hardware", "Home & Garden"]


# SKU Models
class SKUBase(BaseModel):
    """Base SKU model."""
    sku_id: str
    description: str
    category: str
    source_system: SourceSystem
    plant: str
    unit_cost: float


class SKUWithMetrics(SKUBase):
    """SKU with pattern metrics."""
    avg_variance_pct: Optional[float] = None
    recount_frequency_7d: Optional[int] = None
    days_since_last_count: Optional[int] = None
    variance_trend: Optional[VarianceTrend] = None


class SKUWithPrediction(SKUWithMetrics):
    """SKU with prediction data."""
    recount_priority: Optional[PriorityLevel] = None
    urgency_score: Optional[float] = None
    confidence: Optional[float] = None
    is_mock: bool = False
    explanation: Optional[str] = None


class PIDDocument(BaseModel):
    """Physical Inventory Document."""
    pid_id: str
    sku_id: str
    source_system: SourceSystem
    count_date: date
    book_qty: float
    counted_qty: float
    counted_by: str
    variance_pct: Optional[float] = None


class SKUDetail(SKUWithPrediction):
    """Detailed SKU with history."""
    history: List[PIDDocument] = []


# KPI Models
class KPIResponse(BaseModel):
    """KPI aggregates for dashboard."""
    total_pids: int
    high_risk_skus: int
    predictions_today: int
    avg_confidence: float
    total_skus: int
    mock_mode: bool


# Health Models
class HealthResponse(BaseModel):
    """Health check response."""
    rpt_mode: Literal["live", "mock"]
    ai_core_reachable: bool
    database_ok: bool
    last_prediction_time: Optional[datetime] = None


# Filter Models
class SKUFilter(BaseModel):
    """Filters for SKU list."""
    priority: Optional[PriorityLevel] = None
    source: Optional[SourceSystem] = None
    category: Optional[str] = None
    search: Optional[str] = None


# Prediction Models
class PredictionResult(BaseModel):
    """Single prediction result."""
    sku_id: str
    recount_priority: PriorityLevel
    urgency_score: float = Field(ge=0, le=100)
    confidence: float = Field(ge=0, le=1)


class RescoreRequest(BaseModel):
    """Request to trigger rescoring."""
    force: bool = False  # Force rescore even if cache is valid


class RescoreResponse(BaseModel):
    """Response after rescoring."""
    skus_scored: int
    mode: Literal["live", "mock"]
    duration_ms: float
    predictions: List[SKUWithPrediction]


# Pagination
class PaginatedResponse(BaseModel):
    """Paginated list response."""
    items: List[SKUWithPrediction]
    total: int
    page: int
    page_size: int
    total_pages: int
