"""PIDs router - endpoints for viewing PID (Physical Inventory Documents) history."""
from fastapi import APIRouter, Query
from typing import Optional, List
from datetime import date

from ..db import get_db
from ..models import PIDDocument, PaginatedPIDResponse

router = APIRouter(prefix="/api/pids", tags=["PIDs"])


@router.get("", response_model=PaginatedPIDResponse)
async def list_pids(
    sku_id: Optional[str] = Query(None, description="Filter by SKU ID"),
    source: Optional[str] = Query(None, description="Filter by source: ECC, S4HANA"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
):
    """
    List PID documents (physical inventory count records).
    These are the raw count records that predictions are based on.
    """
    with get_db() as conn:
        cursor = conn.cursor()

        # Build query
        query = """
            SELECT
                pid_id,
                sku_id,
                source_system,
                count_date,
                book_qty,
                counted_qty,
                counted_by
            FROM pid_documents
            WHERE 1=1
        """
        count_query = "SELECT COUNT(*) FROM pid_documents WHERE 1=1"
        params = []
        count_params = []

        if sku_id:
            query += " AND sku_id LIKE ?"
            count_query += " AND sku_id LIKE ?"
            pattern = f"%{sku_id}%"
            params.append(pattern)
            count_params.append(pattern)

        if source:
            query += " AND source_system = ?"
            count_query += " AND source_system = ?"
            params.append(source.upper())
            count_params.append(source.upper())

        # Get total count
        cursor.execute(count_query, count_params)
        total = cursor.fetchone()[0]

        # Add ordering and pagination
        query += " ORDER BY count_date DESC, pid_id DESC"
        query += " LIMIT ? OFFSET ?"
        params.extend([page_size, (page - 1) * page_size])

        cursor.execute(query, params)
        rows = cursor.fetchall()

    # Build response
    items = []
    for row in rows:
        row_dict = dict(row)
        variance_pct = ((row_dict['counted_qty'] - row_dict['book_qty']) /
                        row_dict['book_qty'] * 100) if row_dict['book_qty'] > 0 else 0
        items.append(PIDDocument(
            **row_dict,
            variance_pct=round(variance_pct, 2)
        ))

    total_pages = (total + page_size - 1) // page_size

    return PaginatedPIDResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages
    )
