"""Recounts router - endpoints for triggering and viewing recount predictions."""
from fastapi import APIRouter
from datetime import datetime

from ..models import RescoreRequest, RescoreResponse, SKUWithPrediction
from ..pattern_engine import refresh_patterns, get_sku_patterns_with_master
from ..rpt_client import (
    predict_recount_priorities,
    save_predictions_to_cache,
    load_predictions_from_cache
)

router = APIRouter(prefix="/api/recounts", tags=["Recounts"])


def generate_explanation(row: dict) -> str:
    """Generate human-readable explanation from feature values."""
    variance = row.get('avg_variance_pct', 0)
    trend = row.get('variance_trend', 'stable')
    days = row.get('days_since_last_count', 0)

    parts = []

    if variance > 15:
        parts.append(f"{variance:.1f}% variance (very high)")
    elif variance > 10:
        parts.append(f"{variance:.1f}% variance (high)")
    elif variance > 5:
        parts.append(f"{variance:.1f}% variance (moderate)")
    else:
        parts.append(f"{variance:.1f}% variance")

    if trend == 'worsening':
        parts.append("worsening trend over 2 weeks")
    elif trend == 'improving':
        parts.append("improving trend")

    if days > 14:
        parts.append(f"last counted {days} days ago")

    return ", ".join(parts) if parts else "Normal variance levels"


@router.post("/rescore", response_model=RescoreResponse)
async def rescore_priorities(request: RescoreRequest = RescoreRequest()):
    """
    Trigger fresh pattern calculation and RPT scoring.

    1. Refreshes pattern metrics from PID history
    2. Calls SAP-RPT (or mock) for classification/regression
    3. Caches results
    4. Returns ranked list
    """
    # Refresh patterns
    refresh_patterns()

    # Get feature table
    features_df = get_sku_patterns_with_master()

    if features_df.empty:
        return RescoreResponse(
            skus_scored=0,
            mode="mock",
            duration_ms=0,
            predictions=[]
        )

    # Get predictions
    predictions_df, is_mock, duration_ms = predict_recount_priorities(features_df)

    # Save to cache
    save_predictions_to_cache(predictions_df, is_mock)

    # Merge predictions with features for response
    merged = features_df.merge(predictions_df, on='sku_id', how='left')

    # Build response items
    items = []
    for _, row in merged.iterrows():
        row_dict = row.to_dict()
        items.append(SKUWithPrediction(
            sku_id=row_dict['sku_id'],
            description=row_dict['description'],
            category=row_dict['category'],
            source_system=row_dict['source_system'],
            plant=row_dict['plant'],
            unit_cost=row_dict['unit_cost'],
            avg_variance_pct=row_dict.get('avg_variance_pct'),
            recount_frequency_7d=row_dict.get('recount_frequency_7d'),
            days_since_last_count=row_dict.get('days_since_last_count'),
            variance_trend=row_dict.get('variance_trend'),
            recount_priority=row_dict.get('recount_priority'),
            urgency_score=row_dict.get('urgency_score'),
            confidence=row_dict.get('confidence'),
            is_mock=is_mock,
            explanation=generate_explanation(row_dict)
        ))

    # Sort by urgency_score descending
    items.sort(key=lambda x: -(x.urgency_score or 0))

    return RescoreResponse(
        skus_scored=len(items),
        mode="mock" if is_mock else "live",
        duration_ms=round(duration_ms, 2),
        predictions=items
    )
