"""KPIs router - aggregate metrics for dashboard."""
from fastapi import APIRouter
from datetime import datetime

from ..db import get_db
from ..models import KPIResponse
from ..rpt_client import load_predictions_from_cache, check_aicore_reachable

router = APIRouter(prefix="/api/kpis", tags=["KPIs"])


@router.get("", response_model=KPIResponse)
async def get_kpis():
    """Get aggregate KPIs for dashboard display."""
    # Load cached predictions
    predictions_df, is_mock, last_predicted = load_predictions_from_cache()

    with get_db() as conn:
        cursor = conn.cursor()

        # Total PIDs
        cursor.execute("SELECT COUNT(*) FROM pid_documents")
        total_pids = cursor.fetchone()[0]

        # Total SKUs
        cursor.execute("SELECT COUNT(*) FROM sku_master")
        total_skus = cursor.fetchone()[0]

    # Prediction-based KPIs
    high_risk_skus = 0
    predictions_today = 0
    avg_confidence = 0.0

    if predictions_df is not None and not predictions_df.empty:
        high_risk_skus = len(predictions_df[predictions_df['recount_priority'] == 'HIGH'])
        avg_confidence = predictions_df['confidence'].mean()

        # Check if predictions were generated today
        if last_predicted and last_predicted.date() == datetime.now().date():
            predictions_today = len(predictions_df)

    return KPIResponse(
        total_pids=total_pids,
        high_risk_skus=high_risk_skus,
        predictions_today=predictions_today,
        avg_confidence=round(avg_confidence, 3),
        total_skus=total_skus,
        mock_mode=is_mock
    )
