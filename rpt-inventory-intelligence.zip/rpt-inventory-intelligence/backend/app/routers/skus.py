"""SKU router - endpoints for SKU listing and details."""
from fastapi import APIRouter, Query, HTTPException
from typing import Optional, List
from datetime import date, datetime

from ..db import get_db
from ..models import SKUWithPrediction, SKUDetail, PIDDocument, PaginatedResponse, DeepAnalysisResponse
from ..rpt_client import load_predictions_from_cache
from ..gpt_client import analyze_sku_deep, check_gpt_available

router = APIRouter(prefix="/api/skus", tags=["SKUs"])


def generate_explanation(row: dict) -> str:
    """Generate human-readable explanation from feature values."""
    variance = row.get('avg_variance_pct', 0)
    trend = row.get('variance_trend', 'stable')
    days = row.get('days_since_last_count', 0)
    freq = row.get('recount_frequency_7d', 0)

    parts = []

    # Variance description
    if variance > 15:
        parts.append(f"{variance:.1f}% variance (very high)")
    elif variance > 10:
        parts.append(f"{variance:.1f}% variance (high)")
    elif variance > 5:
        parts.append(f"{variance:.1f}% variance (moderate)")
    else:
        parts.append(f"{variance:.1f}% variance")

    # Trend description
    if trend == 'worsening':
        parts.append("worsening trend over 2 weeks")
    elif trend == 'improving':
        parts.append("improving trend")

    # Recency
    if days > 14:
        parts.append(f"last counted {days} days ago")

    return ", ".join(parts) if parts else "Normal variance levels"


@router.get("", response_model=PaginatedResponse)
async def list_skus(
    priority: Optional[str] = Query(None, description="Filter by priority: HIGH, MEDIUM, LOW"),
    source: Optional[str] = Query(None, description="Filter by source: ECC, S4HANA"),
    category: Optional[str] = Query(None, description="Filter by category"),
    search: Optional[str] = Query(None, description="Search in SKU ID or description"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
):
    """
    List SKUs with predictions and metrics.
    Sorted by urgency_score descending by default.
    """
    # Load cached predictions
    predictions_df, is_mock, _ = load_predictions_from_cache()
    predictions_map = {}
    if predictions_df is not None and not predictions_df.empty:
        for _, row in predictions_df.iterrows():
            predictions_map[row['sku_id']] = {
                'recount_priority': row['recount_priority'],
                'urgency_score': row['urgency_score'],
                'confidence': row['confidence'],
            }

    with get_db() as conn:
        # Build query
        query = """
            SELECT
                m.sku_id,
                m.description,
                m.category,
                m.source_system,
                m.plant,
                m.unit_cost,
                COALESCE(p.avg_variance_pct, 0) as avg_variance_pct,
                COALESCE(p.recount_frequency_7d, 0) as recount_frequency_7d,
                COALESCE(p.days_since_last_count, 999) as days_since_last_count,
                COALESCE(p.variance_trend, 'stable') as variance_trend
            FROM sku_master m
            LEFT JOIN daily_count_pattern p ON m.sku_id = p.sku_id
            WHERE 1=1
        """
        params = []

        if source:
            query += " AND m.source_system = ?"
            params.append(source.upper())

        if category:
            query += " AND m.category = ?"
            params.append(category)

        if search:
            query += " AND (m.sku_id LIKE ? OR m.description LIKE ?)"
            search_pattern = f"%{search}%"
            params.extend([search_pattern, search_pattern])

        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()

    # Build response with predictions
    items = []
    for row in rows:
        row_dict = dict(row)
        sku_id = row_dict['sku_id']

        # Add prediction data
        pred = predictions_map.get(sku_id, {
            'recount_priority': None,
            'urgency_score': None,
            'confidence': None,
        })

        item = SKUWithPrediction(
            **row_dict,
            recount_priority=pred.get('recount_priority'),
            urgency_score=pred.get('urgency_score'),
            confidence=pred.get('confidence'),
            is_mock=is_mock,
            explanation=generate_explanation(row_dict)
        )
        items.append(item)

    # Filter by priority (post-query since it's from cache)
    if priority:
        items = [i for i in items if i.recount_priority == priority.upper()]

    # Sort by urgency_score descending (nulls last)
    items.sort(key=lambda x: (x.urgency_score is None, -(x.urgency_score or 0)))

    # Paginate
    total = len(items)
    total_pages = (total + page_size - 1) // page_size
    start = (page - 1) * page_size
    end = start + page_size
    paginated_items = items[start:end]

    return PaginatedResponse(
        items=paginated_items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages
    )


@router.get("/categories", response_model=List[str])
async def list_categories():
    """Get list of all categories."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT category FROM sku_master ORDER BY category")
        rows = cursor.fetchall()
    return [row[0] for row in rows]


@router.get("/{sku_id}", response_model=SKUDetail)
async def get_sku_detail(sku_id: str):
    """Get detailed SKU information including 60-day history."""
    # Load cached predictions
    predictions_df, is_mock, _ = load_predictions_from_cache()
    pred_data = {}
    if predictions_df is not None and not predictions_df.empty:
        pred_row = predictions_df[predictions_df['sku_id'] == sku_id]
        if not pred_row.empty:
            pred_data = pred_row.iloc[0].to_dict()

    with get_db() as conn:
        cursor = conn.cursor()

        # Get SKU with patterns
        cursor.execute("""
            SELECT
                m.sku_id,
                m.description,
                m.category,
                m.source_system,
                m.plant,
                m.unit_cost,
                COALESCE(p.avg_variance_pct, 0) as avg_variance_pct,
                COALESCE(p.recount_frequency_7d, 0) as recount_frequency_7d,
                COALESCE(p.days_since_last_count, 999) as days_since_last_count,
                COALESCE(p.variance_trend, 'stable') as variance_trend
            FROM sku_master m
            LEFT JOIN daily_count_pattern p ON m.sku_id = p.sku_id
            WHERE m.sku_id = ?
        """, [sku_id])
        row = cursor.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail=f"SKU {sku_id} not found")

        row_dict = dict(row)

        # Get PID history
        cursor.execute("""
            SELECT
                pid_id, sku_id, source_system, count_date,
                book_qty, counted_qty, counted_by
            FROM pid_documents
            WHERE sku_id = ?
            ORDER BY count_date DESC
            LIMIT 100
        """, [sku_id])
        pids = cursor.fetchall()

    # Build history
    history = []
    for pid in pids:
        pid_dict = dict(pid)
        variance_pct = ((pid_dict['counted_qty'] - pid_dict['book_qty']) /
                        pid_dict['book_qty'] * 100) if pid_dict['book_qty'] > 0 else 0
        history.append(PIDDocument(
            **pid_dict,
            variance_pct=round(variance_pct, 2)
        ))

    return SKUDetail(
        **row_dict,
        recount_priority=pred_data.get('recount_priority'),
        urgency_score=pred_data.get('urgency_score'),
        confidence=pred_data.get('confidence'),
        is_mock=is_mock,
        explanation=generate_explanation(row_dict),
        history=history
    )


@router.post("/{sku_id}/analysis", response_model=DeepAnalysisResponse)
async def get_deep_analysis(sku_id: str):
    """
    Get deep AI analysis for a specific SKU using GPT.

    This is the HYBRID AI feature:
    - SAP-RPT handles bulk scoring (classification + regression)
    - GPT provides detailed analysis for individual SKUs

    Returns detailed root cause analysis, recommendations, and risk factors.
    """
    # Load cached predictions
    predictions_df, is_mock, _ = load_predictions_from_cache()
    pred_data = {}
    if predictions_df is not None and not predictions_df.empty:
        pred_row = predictions_df[predictions_df['sku_id'] == sku_id]
        if not pred_row.empty:
            pred_data = pred_row.iloc[0].to_dict()

    with get_db() as conn:
        cursor = conn.cursor()

        # Get SKU with patterns
        cursor.execute("""
            SELECT
                m.sku_id,
                m.description,
                m.category,
                m.source_system,
                m.plant,
                m.unit_cost,
                COALESCE(p.avg_variance_pct, 0) as avg_variance_pct,
                COALESCE(p.recount_frequency_7d, 0) as recount_frequency_7d,
                COALESCE(p.days_since_last_count, 999) as days_since_last_count,
                COALESCE(p.variance_trend, 'stable') as variance_trend
            FROM sku_master m
            LEFT JOIN daily_count_pattern p ON m.sku_id = p.sku_id
            WHERE m.sku_id = ?
        """, [sku_id])
        row = cursor.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail=f"SKU {sku_id} not found")

        sku_data = dict(row)

        # Get PID history for analysis
        cursor.execute("""
            SELECT
                pid_id, sku_id, source_system, count_date,
                book_qty, counted_qty, counted_by
            FROM pid_documents
            WHERE sku_id = ?
            ORDER BY count_date DESC
            LIMIT 20
        """, [sku_id])
        pids = cursor.fetchall()

    # Build history for GPT
    history = []
    for pid in pids:
        pid_dict = dict(pid)
        history.append(pid_dict)

    # Combine all data for GPT analysis
    sku_data['history'] = history
    sku_data['recount_priority'] = pred_data.get('recount_priority', 'UNKNOWN')
    sku_data['urgency_score'] = pred_data.get('urgency_score', 0)
    sku_data['confidence'] = pred_data.get('confidence', 0)

    # Call LLM for deep analysis
    result = analyze_sku_deep(sku_data)

    return DeepAnalysisResponse(
        sku_id=sku_id,
        problem_summary=result.get('problem_summary'),
        root_causes=result.get('root_causes', []),
        financial_impact=result.get('financial_impact'),
        mitigation_actions=result.get('mitigation_actions', []),
        risk_level=result.get('risk_level'),
        confidence_score=result.get('confidence_score'),
        key_insight=result.get('key_insight'),
        analysis=result.get('analysis'),
        recommendations=result.get('recommendations', []),
        risk_factors=result.get('risk_factors', []),
        model_used=result['model_used'],
        is_mock=result['is_mock'],
        duration_ms=result['duration_ms'],
        generated_at=datetime.fromisoformat(result['generated_at'])
    )


@router.get("/{sku_id}/analysis/status")
async def get_analysis_status():
    """Check if GPT deep analysis is available."""
    available, model = check_gpt_available()
    return {
        "available": available,
        "model": model,
        "mode": "mock" if not available else "live"
    }
