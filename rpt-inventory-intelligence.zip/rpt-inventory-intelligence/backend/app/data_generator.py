"""
Synthetic data generator for Physical Inventory Intelligence demo.

Generates:
- 120 SKUs across 5 categories and 3 plants
- 60 days of PID history with realistic variance patterns
- ~80% normal variance, ~12% worsening drift, ~8% sporadic anomalies

Deterministic via fixed random seed for reproducible demos.
"""
import random
import csv
from datetime import date, timedelta
from pathlib import Path
from typing import List, Tuple
import numpy as np

from .db import get_db

# Set seed for reproducibility
random.seed(42)
np.random.seed(42)

# Configuration
NUM_SKUS = 120
NUM_DAYS = 60
CATEGORIES = ["Electronics", "Apparel", "Grocery", "Hardware", "Home & Garden"]
PLANTS = ["PL01", "PL02", "PL03", "PL04", "PL05"]
EMPLOYEES = [f"EMP{str(i).zfill(3)}" for i in range(1, 16)]  # 15 employees

# Product name templates per category
PRODUCT_TEMPLATES = {
    "Electronics": [
        "Wireless {adj} Headphones", "USB-C {adj} Charger", "Smart {adj} Watch",
        "Bluetooth {adj} Speaker", "LED {adj} Monitor", "Portable {adj} Battery",
        "Gaming {adj} Controller", "Webcam {adj} HD", "Mechanical {adj} Keyboard"
    ],
    "Apparel": [
        "{adj} Cotton T-Shirt", "{adj} Denim Jeans", "{adj} Running Shoes",
        "{adj} Winter Jacket", "{adj} Polo Shirt", "{adj} Cargo Pants",
        "{adj} Athletic Socks", "{adj} Baseball Cap", "{adj} Hoodie"
    ],
    "Grocery": [
        "Organic {adj} Pasta", "{adj} Coffee Beans", "Natural {adj} Honey",
        "Premium {adj} Olive Oil", "{adj} Breakfast Cereal", "Artisan {adj} Bread",
        "{adj} Protein Bar", "Fresh {adj} Juice", "{adj} Trail Mix"
    ],
    "Hardware": [
        "{adj} Power Drill", "Steel {adj} Hammer", "{adj} Screwdriver Set",
        "{adj} Measuring Tape", "LED {adj} Flashlight", "{adj} Tool Box",
        "{adj} Paint Roller", "Electric {adj} Sander", "{adj} Safety Goggles"
    ],
    "Home & Garden": [
        "{adj} Plant Pot", "Garden {adj} Hose", "{adj} Solar Light",
        "{adj} Bird Feeder", "Outdoor {adj} Chair", "{adj} Grill Cover",
        "{adj} Lawn Mower", "Wooden {adj} Planter", "{adj} Wind Chime"
    ]
}

ADJECTIVES = [
    "Pro", "Elite", "Classic", "Premium", "Basic", "Deluxe", "Ultra",
    "Mini", "Max", "Lite", "Plus", "Standard", "Advanced", "Essential"
]


def generate_product_name(category: str, index: int) -> str:
    """Generate a plausible product name for the category."""
    templates = PRODUCT_TEMPLATES.get(category, ["Generic Product {adj}"])
    template = templates[index % len(templates)]
    adj = ADJECTIVES[index % len(ADJECTIVES)]
    return template.format(adj=adj)


def generate_skus() -> List[dict]:
    """Generate 120 SKU records."""
    skus = []
    sku_counter = 10000

    for i in range(NUM_SKUS):
        category = CATEGORIES[i % len(CATEGORIES)]
        plant = PLANTS[i % len(PLANTS)]
        # Alternate between ECC and S4HANA
        source_system = "ECC" if i % 2 == 0 else "S4HANA"

        sku = {
            "sku_id": f"SKU-{sku_counter + i}",
            "description": generate_product_name(category, i // len(CATEGORIES)),
            "category": category,
            "source_system": source_system,
            "plant": plant,
            "unit_cost": round(random.uniform(5.0, 500.0), 2)
        }
        skus.append(sku)

    return skus


def assign_sku_behavior(skus: List[dict]) -> dict:
    """
    Assign variance behavior to each SKU.
    - ~55% normal (small variance) -> LOW priority
    - ~25% medium drift -> MEDIUM priority
    - ~20% worsening drift or sporadic -> HIGH priority (7-8+ SKUs)
    """
    behaviors = {}
    indices = list(range(len(skus)))
    random.shuffle(indices)

    normal_count = int(NUM_SKUS * 0.55)      # 55% -> LOW (~66 SKUs)
    medium_count = int(NUM_SKUS * 0.25)      # 25% -> MEDIUM (~30 SKUs)
    # Remaining ~20% are worsening/sporadic -> HIGH (~24 SKUs, but RPT will pick 8-10)

    for i, idx in enumerate(indices):
        sku_id = skus[idx]["sku_id"]
        if i < normal_count:
            behaviors[sku_id] = "normal"
        elif i < normal_count + medium_count:
            behaviors[sku_id] = "medium"
        else:
            # More worsening than sporadic for consistent HIGH signals
            if random.random() < 0.8:
                behaviors[sku_id] = "worsening"
            else:
                behaviors[sku_id] = "sporadic"

    return behaviors


def generate_pids(skus: List[dict], behaviors: dict) -> List[dict]:
    """
    Generate 60 days of PID documents for each SKU.
    1-4 PIDs per SKU per week (Poisson-distributed).
    """
    pids = []
    end_date = date.today()
    start_date = end_date - timedelta(days=NUM_DAYS)

    pid_counter = {"ECC": 100000, "S4HANA": 100000}

    for sku in skus:
        sku_id = sku["sku_id"]
        source = sku["source_system"]
        behavior = behaviors[sku_id]

        # Base book quantity for this SKU (between 100 and 5000 units)
        base_qty = random.randint(100, 5000)

        # Generate count dates using Poisson distribution (avg 2 per week)
        current_date = start_date
        week_count = 0

        while current_date <= end_date:
            # Determine number of counts this week (Poisson lambda=2)
            counts_this_week = np.random.poisson(2)
            counts_this_week = min(max(counts_this_week, 1), 4)  # Clamp to 1-4

            # Distribute counts within the week
            week_days = [current_date + timedelta(days=d) for d in range(7) if current_date + timedelta(days=d) <= end_date]
            if week_days:
                count_days = random.sample(week_days, min(counts_this_week, len(week_days)))

                for count_date in sorted(count_days):
                    # Calculate variance based on behavior
                    variance_pct = calculate_variance(behavior, current_date, end_date, week_count)

                    # Book qty varies slightly over time
                    book_qty = base_qty + random.randint(-50, 50)
                    book_qty = max(10, book_qty)  # Ensure positive

                    # Counted qty based on variance
                    counted_qty = round(book_qty * (1 + variance_pct / 100))
                    counted_qty = max(0, counted_qty)

                    prefix = "ECC-PID" if source == "ECC" else "S4H-PID"
                    pid_id = f"{prefix}-{pid_counter[source]:06d}"
                    pid_counter[source] += 1

                    pids.append({
                        "pid_id": pid_id,
                        "sku_id": sku_id,
                        "source_system": source,
                        "count_date": count_date.isoformat(),
                        "book_qty": book_qty,
                        "counted_qty": counted_qty,
                        "counted_by": random.choice(EMPLOYEES)
                    })

            current_date += timedelta(days=7)
            week_count += 1

    return pids


def calculate_variance(behavior: str, current_date: date, end_date: date, week_num: int) -> float:
    """
    Calculate variance percentage based on SKU behavior.

    - normal: ±3% random variance -> LOW priority
    - medium: 5-10% variance with slight trend -> MEDIUM priority
    - worsening: starts at ~1%, grows to 15-20% in last 2-3 weeks -> HIGH priority
    - sporadic: mostly ±3%, but 1-2 isolated spikes >25% -> HIGH priority
    """
    days_remaining = (end_date - current_date).days

    if behavior == "normal":
        # Normal: small Gaussian noise within ±3%
        return np.random.normal(0, 1.5)

    elif behavior == "medium":
        # Medium: consistent 5-10% variance with slight worsening trend
        total_days = NUM_DAYS
        days_elapsed = total_days - days_remaining
        progress = days_elapsed / total_days

        # Base variance 5-8%, with slight increase over time
        base_variance = 5 + progress * 3 + np.random.normal(0, 1.5)
        # Randomly positive or negative variance
        return base_variance if random.random() > 0.4 else -base_variance

    elif behavior == "worsening":
        # Worsening: variance grows over time -> HIGH priority
        # Start at 3-5%, grow to 15-25% in last ~25 days
        total_days = NUM_DAYS

        if days_remaining <= 25:
            # Strong growth in last 3-4 weeks
            progress = 1 - (days_remaining / 25)
            base_variance = 5 + progress * 20  # 5% to 25%
            variance = np.random.normal(base_variance, 2)
            # Ensure direction is consistent (positive = over-count)
            return abs(variance) if random.random() > 0.3 else -abs(variance)
        else:
            # Early period: slightly elevated variance
            return np.random.normal(3, 1.5)

    elif behavior == "sporadic":
        # Sporadic: mostly normal, but 1-2 large spikes
        # Create deterministic spike days based on SKU characteristics
        spike_probability = 0.04  # ~2-3 spikes over 60 days with avg 2 counts/week

        if random.random() < spike_probability:
            # Big anomaly: 25-40% variance
            spike = random.uniform(25, 40)
            return spike if random.random() > 0.5 else -spike
        else:
            return np.random.normal(0, 1.5)

    return 0


def save_to_database(skus: List[dict], pids: List[dict]):
    """Save generated data to SQLite database."""
    with get_db() as conn:
        cursor = conn.cursor()

        # Insert SKUs
        cursor.executemany("""
            INSERT OR REPLACE INTO sku_master
            (sku_id, description, category, source_system, plant, unit_cost)
            VALUES (:sku_id, :description, :category, :source_system, :plant, :unit_cost)
        """, skus)

        # Insert PIDs
        cursor.executemany("""
            INSERT OR REPLACE INTO pid_documents
            (pid_id, sku_id, source_system, count_date, book_qty, counted_qty, counted_by)
            VALUES (:pid_id, :sku_id, :source_system, :count_date, :book_qty, :counted_qty, :counted_by)
        """, pids)

        conn.commit()

    print(f"✅ Saved {len(skus)} SKUs and {len(pids)} PIDs to database")


def export_to_csv(skus: List[dict], pids: List[dict], output_dir: Path):
    """Export data to CSV files for inspection."""
    output_dir.mkdir(parents=True, exist_ok=True)

    # Export SKUs
    sku_path = output_dir / "sku_master.csv"
    with open(sku_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=skus[0].keys())
        writer.writeheader()
        writer.writerows(skus)
    print(f"📄 Exported SKUs to {sku_path}")

    # Export PIDs
    pid_path = output_dir / "pid_documents.csv"
    with open(pid_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=pids[0].keys())
        writer.writeheader()
        writer.writerows(pids)
    print(f"📄 Exported PIDs to {pid_path}")


def generate_all_data(export_csv: bool = True) -> Tuple[List[dict], List[dict]]:
    """
    Main function to generate all synthetic data.
    Returns (skus, pids) tuple.
    """
    print("🏭 Generating synthetic Physical Inventory data...")
    print(f"   - {NUM_SKUS} SKUs across {len(CATEGORIES)} categories")
    print(f"   - {NUM_DAYS} days of history")
    print(f"   - Split between ECC and S/4HANA source systems")

    # Generate data
    skus = generate_skus()
    behaviors = assign_sku_behavior(skus)
    pids = generate_pids(skus, behaviors)

    # Log behavior distribution
    behavior_counts = {"normal": 0, "medium": 0, "worsening": 0, "sporadic": 0}
    for b in behaviors.values():
        behavior_counts[b] += 1
    print(f"   - Behavior distribution: {behavior_counts}")

    # Save to database
    save_to_database(skus, pids)

    # Optionally export to CSV
    if export_csv:
        output_dir = Path(__file__).parent.parent / "data"
        export_to_csv(skus, pids, output_dir)

    print("✅ Data generation complete!")
    return skus, pids


if __name__ == "__main__":
    generate_all_data()
