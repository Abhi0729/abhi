"""
LLM Client for deep analysis of individual SKUs via SAP AI Core.

Supports multiple LLM providers deployed in AI Core:
- Claude models (anthropic--claude-4.5-sonnet, claude-sonnet-4-5, etc.)
- GPT models (gpt-4o, gpt-4, gpt-35-turbo, gpt-5-mini, etc.)

Falls back to mock analysis when unavailable.

This creates a HYBRID AI architecture:
- SAP-RPT: Bulk scoring of all SKUs (classification + regression)
- LLM: Deep analysis of single SKU (detailed explanations, recommendations)
"""
import os
import time
import logging
import httpx
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
import json

from .config import is_aicore_configured, get_settings, get_aicore_credentials

logger = logging.getLogger(__name__)

# Model patterns to look for (in order of preference)
# Format: (pattern_to_match, provider_type)
LLM_MODEL_PATTERNS = [
    ('claude', 'anthropic'),  # Prefer Claude - works reliably
    ('anthropic', 'anthropic'),
    ('gpt-4o', 'openai'),
    ('gpt-4', 'openai'),
    ('gpt-5', 'openai'),
    ('gpt-35', 'openai'),
    ('gpt-3.5', 'openai'),
]


class MockGPTAnalyzer:
    """
    Mock analyzer that generates executive-level analysis when AI Core is unavailable.
    Uses professional terminology suitable for C-level presentations.
    """

    def analyze(self, sku_data: dict) -> dict:
        """Generate professional mock analysis based on SKU data."""
        logger.warning("⚠️ Using mock LLM analyzer — AI Core LLM not available")

        priority = sku_data.get('recount_priority', 'MEDIUM')
        variance = sku_data.get('avg_variance_pct', 0)
        trend = sku_data.get('variance_trend', 'stable')
        sku_id = sku_data.get('sku_id', 'Unknown')
        category = sku_data.get('category', 'Unknown')
        unit_cost = sku_data.get('unit_cost', 0)
        days_since = sku_data.get('days_since_last_count', 0)
        plant = sku_data.get('plant', 'Unknown')

        # Calculate estimated financial impact
        estimated_units_affected = int(abs(variance) * 10)  # Rough estimate
        value_at_risk = estimated_units_affected * unit_cost

        if priority == 'HIGH':
            problem_summary = f"Critical inventory control deviation detected for {category} asset {sku_id} at {plant} facility, with {variance:.1f}% mean variance rate representing significant operational and financial exposure requiring immediate executive attention and cross-functional remediation efforts."

            root_causes = [
                {
                    "cause": "Transaction Synchronization Latency",
                    "description": f"Material movements are not being captured in real-time at the {plant} facility, creating systematic discrepancies between physical inventory and ERP book quantities that compound over time and affect downstream planning."
                },
                {
                    "cause": "Process Compliance Degradation",
                    "description": f"Standard operating procedures for {category} inventory handling show evidence of significant deviation, particularly in receiving verification, put-away confirmation workflows, and cycle count execution protocols."
                },
                {
                    "cause": "Master Data Integrity Gap",
                    "description": f"Unit of measure configurations, storage location mappings, or material master records may contain inconsistencies that systematically affect accurate quantity tracking and reporting for this SKU classification."
                }
            ]

            financial_impact = {
                "estimated_value_at_risk": f"${value_at_risk:,.2f} - ${value_at_risk * 1.5:,.2f}",
                "impact_description": f"Based on {variance:.1f}% variance and ${unit_cost:.2f} unit valuation, total exposure includes potential inventory write-offs, customer fulfillment failures, increased safety stock requirements, and working capital inefficiency."
            }

            mitigation_actions = [
                {
                    "action": "Executive-Sponsored Physical Verification",
                    "priority": "Immediate",
                    "description": "Commission a fully supervised wall-to-wall physical inventory count with dual verification protocol, real-time variance documentation, and immediate root cause investigation for any discrepancies discovered."
                },
                {
                    "action": "Transaction Audit and Reconciliation",
                    "priority": "Short-term",
                    "description": "Conduct comprehensive forensic analysis of all material movements, inventory adjustments, and transfer postings over the trailing 30-day period to identify patterns, anomalies, and systemic process failures."
                },
                {
                    "action": "Process Re-engineering Initiative",
                    "priority": "Long-term",
                    "description": f"Implement an enhanced inventory control framework for {category} products including mandatory barcode scanning validation, automated discrepancy alerts, and real-time exception reporting dashboards."
                }
            ]

            risk_level = "Critical" if variance > 15 or trend == 'worsening' else "High"
            confidence_score = 92
            key_insight = f"Immediate executive intervention is strongly recommended. The {trend} trajectory of variance in this high-value {category} SKU indicates a systemic control weakness requiring coordinated cross-functional remediation."

        elif priority == 'MEDIUM':
            problem_summary = f"Elevated inventory variance identified for {category} SKU {sku_id} at {plant}, indicating a process optimization opportunity with manageable risk exposure that warrants proactive monitoring and targeted intervention strategies."

            root_causes = [
                {
                    "cause": "Cycle Count Timing Discrepancy",
                    "description": f"Current verification frequency may be insufficient for this {category} velocity profile, allowing variance accumulation between count cycles and reducing early detection of emerging issues."
                },
                {
                    "cause": "Operational Workflow Variance",
                    "description": "Minor but consistent deviations in standard handling procedures across different shifts, operators, or work zones are contributing to incremental accuracy erosion over time."
                },
                {
                    "cause": "System Configuration Optimization",
                    "description": "Tolerance thresholds, automated alert parameters, and ABC classification settings may require recalibration to better match this product classification's specific characteristics and business value."
                }
            ]

            financial_impact = {
                "estimated_value_at_risk": f"${value_at_risk:,.2f}",
                "impact_description": f"Moderate exposure with {variance:.1f}% variance rate. This situation is addressable through standard continuous improvement protocols and targeted process adjustments without requiring significant capital investment or organizational restructuring."
            }

            mitigation_actions = [
                {
                    "action": "Prioritized Cycle Count Inclusion",
                    "priority": "Immediate",
                    "description": "Escalate this SKU to the next scheduled verification cycle with enhanced documentation requirements, mandatory supervisor sign-off, and detailed variance investigation protocols."
                },
                {
                    "action": "Root Cause Investigation",
                    "priority": "Short-term",
                    "description": "Analyze transaction patterns, operator-specific variance rates, and shift-level performance metrics to identify targeted improvement opportunities and training needs."
                },
                {
                    "action": "Control Parameter Optimization",
                    "priority": "Long-term",
                    "description": f"Review and adjust inventory control thresholds, alert parameters, and monitoring frequencies for the {category} product family based on value, velocity, and criticality characteristics."
                }
            ]

            risk_level = "Medium"
            confidence_score = 85
            key_insight = f"Proactive monitoring and targeted intervention recommended. This {category} SKU shows variance patterns that are addressable through focused operational refinement without escalation to crisis management protocols."

        else:
            problem_summary = f"Inventory control metrics for {category} SKU {sku_id} are operating well within acceptable tolerance bands at {plant}, demonstrating effective inventory management practices and mature process controls that serve as a model for operational excellence."

            root_causes = [
                {
                    "cause": "Operational Excellence Baseline",
                    "description": f"Current {variance:.1f}% variance rate reflects mature inventory control processes, effective standard operating procedures, and consistent execution across all operational touchpoints."
                },
                {
                    "cause": "Consistent Process Adherence",
                    "description": "Verification activities and material handling workflows are being executed with appropriate rigor, documentation standards, and accountability measures across all shifts and personnel."
                },
                {
                    "cause": "Effective System Integration",
                    "description": "ERP transaction capture and physical inventory movements are well-synchronized for this SKU classification, with minimal latency between physical events and system recording."
                }
            ]

            financial_impact = {
                "estimated_value_at_risk": f"< ${max(value_at_risk, 100):,.2f}",
                "impact_description": "Minimal exposure. Current variance levels represent acceptable operational tolerance with no material financial impact. Maintain current practices to preserve this performance level."
            }

            mitigation_actions = [
                {
                    "action": "Maintain Standard Verification Cadence",
                    "priority": "Long-term",
                    "description": "Continue current cycle counting schedule and monitoring protocols without modification. Ensure consistency in execution and documentation to preserve current accuracy levels."
                },
                {
                    "action": "Best Practice Documentation",
                    "priority": "Long-term",
                    "description": f"Document successful control practices for this {category} SKU as a reference model and training resource for similar product classifications showing higher variance."
                },
                {
                    "action": "Continuous Monitoring",
                    "priority": "Long-term",
                    "description": "Maintain dashboard visibility and automated alert thresholds to detect any emerging variance trends that might require early intervention or process adjustment."
                }
            ]

            risk_level = "Low"
            confidence_score = 88
            key_insight = f"Exemplary inventory control performance demonstrated. Consider this {category} SKU's management approach as a benchmark and replicable model for operational excellence initiatives across similar product categories."

        return {
            'problem_summary': problem_summary,
            'root_causes': root_causes,
            'financial_impact': financial_impact,
            'mitigation_actions': mitigation_actions,
            'risk_level': risk_level,
            'confidence_score': confidence_score,
            'key_insight': key_insight,
            'analysis': f"## Executive Summary\n\n{problem_summary}\n\n### Risk Assessment: {risk_level}",
            'recommendations': [a['action'] for a in mitigation_actions],
            'risk_factors': [c['cause'] for c in root_causes],
            'model_used': 'mock-analyzer',
            'is_mock': True
        }


class LLMClient:
    """
    Client for LLM analysis via SAP AI Core.
    Auto-detects available LLM deployments (Claude or GPT) or uses configured deployment ID.
    """

    def __init__(self):
        self._mock_analyzer = MockGPTAnalyzer()
        self._token = None
        self._token_expires = 0
        self._llm_deployment_id = None
        self._llm_model_name = None
        self._llm_provider = None  # 'anthropic' or 'openai'
        self._initialized = False

    def _get_token(self) -> Optional[str]:
        """Get OAuth token for AI Core."""
        creds = get_aicore_credentials()
        if not creds:
            return None

        # Check if token is still valid
        if self._token and time.time() < self._token_expires - 60:
            return self._token

        try:
            auth_url = creds['auth_url'].rstrip('/') + '/oauth/token'
            response = httpx.post(
                auth_url,
                data={
                    'grant_type': 'client_credentials',
                    'client_id': creds['client_id'],
                    'client_secret': creds['client_secret'],
                },
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                timeout=30.0
            )
            response.raise_for_status()
            data = response.json()
            self._token = data['access_token']
            self._token_expires = time.time() + data.get('expires_in', 3600)
            return self._token
        except Exception as e:
            logger.error(f"Failed to get AI Core token: {e}")
            return None

    def _auto_detect_llm_deployment(self) -> Optional[Tuple[str, str, str]]:
        """
        Auto-detect LLM deployment from AI Core.
        Returns (deployment_id, model_name, provider) or None.
        """
        try:
            from ai_core_sdk.ai_core_v2_client import AICoreV2Client

            creds = get_aicore_credentials()
            if not creds:
                return None

            client = AICoreV2Client(
                base_url=creds['base_url'].rstrip('/') + '/v2',
                auth_url=creds['auth_url'].rstrip('/') + '/oauth/token',
                client_id=creds['client_id'],
                client_secret=creds['client_secret'],
                resource_group=creds['resource_group']
            )

            deployments = client.deployment.query()

            # Check each pattern in order of preference
            for pattern, provider in LLM_MODEL_PATTERNS:
                for d in deployments.resources:
                    if str(d.status) != 'Status.RUNNING':
                        continue

                    details = d.details or {}
                    resources = details.get('resources', {})
                    backend = resources.get('backend_details', {})
                    model = backend.get('model', {})
                    model_name = model.get('name', '').lower()

                    if pattern in model_name:
                        logger.info(f"✅ Auto-detected LLM deployment: {d.id} ({model_name}, {provider})")
                        return (d.id, model_name, provider)

            logger.warning("⚠️ No LLM deployment found in AI Core")
            return None

        except Exception as e:
            logger.error(f"Failed to auto-detect LLM deployment: {e}")
            return None

    def _initialize(self) -> bool:
        """Initialize the LLM client, detecting deployment if needed."""
        if self._initialized:
            return self._llm_deployment_id is not None

        self._initialized = True

        if not is_aicore_configured():
            logger.warning("⚠️ AI Core not configured for LLM")
            return False

        settings = get_settings()

        # Check if deployment ID is configured
        if settings.gpt_deployment_id:
            self._llm_deployment_id = settings.gpt_deployment_id
            # Determine provider from deployment
            result = self._auto_detect_llm_deployment()
            if result:
                # Use auto-detected info if available
                for d_id, name, provider in [result]:
                    if d_id == settings.gpt_deployment_id:
                        self._llm_model_name = name
                        self._llm_provider = provider
                        break
            # Default to anthropic (Claude) since GPT-5-mini has issues
            if not self._llm_provider:
                self._llm_model_name = 'configured-llm'
                self._llm_provider = 'anthropic'  # Default to Anthropic format
            logger.info(f"✅ Using configured LLM deployment: {self._llm_deployment_id} ({self._llm_provider})")
            return True

        # Auto-detect LLM deployment
        result = self._auto_detect_llm_deployment()
        if result:
            self._llm_deployment_id, self._llm_model_name, self._llm_provider = result
            return True

        return False

    def is_available(self) -> bool:
        """Check if LLM analysis is available."""
        return self._initialize()

    def _build_prompt(self, sku_data: dict) -> str:
        """Build the analysis prompt for LLM - concise, executive-level insights."""
        # Format history summary (not full table)
        history = sku_data.get('history', [])[:5]
        history_summary = []
        for h in history:
            variance = ((h.get('counted_qty', 0) - h.get('book_qty', 0)) / max(h.get('book_qty', 1), 1)) * 100
            history_summary.append(f"{h.get('count_date', 'N/A')}: {variance:+.1f}%")

        # Calculate specific metrics
        variance_pct = sku_data.get('avg_variance_pct', 0)
        unit_cost = sku_data.get('unit_cost', 0)
        trend = sku_data.get('variance_trend', 'stable')
        days_since = sku_data.get('days_since_last_count', 0)
        category = sku_data.get('category', 'Unknown')

        prompt = f"""You are an executive inventory analyst. Provide BRIEF, HIGH-IMPACT analysis.

SKU: {sku_data.get('sku_id')} | {sku_data.get('description')} | {category}
Plant: {sku_data.get('plant')} | Unit Cost: ${unit_cost:.2f}
Variance: {variance_pct:.1f}% | Trend: {trend} | Days since count: {days_since}
Recent variances: {', '.join(history_summary) if history_summary else 'N/A'}

RULES - BE MODERATELY DETAILED:
- problem_summary: 20-30 words, provide clear context and business impact
- Each root cause description: 20-25 words, explain the specific issue and its operational effect
- Each action description: 20-28 words, provide actionable steps with expected outcomes
- financial impact_description: 25-35 words, include specific business implications
- key_insight: 20-25 words, provide strategic recommendation with reasoning

Respond with ONLY this JSON (no markdown):
{{
  "problem_summary": "Clear issue statement with context - 20-30 words describing the problem and its significance",
  "root_causes": [
    {{"cause": "3-5 word title", "description": "20-25 words explaining the specific issue and its operational impact"}},
    {{"cause": "3-5 word title", "description": "20-25 words explaining the specific issue and its operational impact"}}
  ],
  "financial_impact": {{
    "estimated_value_at_risk": "${int(variance_pct * unit_cost * 10):,} - ${int(variance_pct * unit_cost * 50):,}",
    "impact_description": "25-35 words on business impact including working capital, fulfillment risks, and operational costs"
  }},
  "mitigation_actions": [
    {{"action": "3-6 word title", "priority": "Immediate", "description": "20-28 words with specific actionable steps and expected business outcomes"}},
    {{"action": "3-6 word title", "priority": "Short-term", "description": "20-28 words with specific actionable steps and expected business outcomes"}}
  ],
  "risk_level": "{"Critical" if variance_pct > 15 else "High" if variance_pct > 10 or trend == "worsening" else "Medium" if variance_pct > 5 else "Low"}",
  "confidence_score": {88 if variance_pct > 10 else 82 if variance_pct > 5 else 75},
  "key_insight": "Strategic recommendation with reasoning - 20-25 words providing actionable guidance for stakeholders"
}}"""

        return prompt

    def _call_llm(self, prompt: str) -> dict:
        """Call LLM via AI Core inference API."""
        creds = get_aicore_credentials()
        token = self._get_token()

        if not token or not creds or not self._llm_deployment_id:
            raise Exception("LLM client not properly initialized")

        base_url = creds['base_url'].rstrip('/')

        if self._llm_provider == 'anthropic':
            # Use Anthropic/Claude format with /invoke endpoint
            url = f"{base_url}/v2/inference/deployments/{self._llm_deployment_id}/invoke"
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 1000,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }
        else:
            # Use OpenAI format with /v1/chat/completions endpoint
            url = f"{base_url}/v2/inference/deployments/{self._llm_deployment_id}/v1/chat/completions"
            request_body = {
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a concise inventory analyst. Keep all responses brief and impactful."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "max_completion_tokens": 1000
            }

        logger.info(f"Calling LLM ({self._llm_provider}) at {url}")

        response = httpx.post(
            url,
            json=request_body,
            headers={
                'Authorization': f'Bearer {token}',
                'AI-Resource-Group': creds['resource_group'],
                'Content-Type': 'application/json',
            },
            timeout=120.0
        )

        if response.status_code != 200:
            logger.error(f"LLM API error: {response.status_code} - {response.text}")
            response.raise_for_status()

        result = response.json()
        return result

    def _parse_response(self, response: dict) -> dict:
        """Parse LLM response into structured format."""
        import json as json_module
        import re

        try:
            if self._llm_provider == 'anthropic':
                # Anthropic response format
                content = response.get('content', [])
                if content and len(content) > 0:
                    text = content[0].get('text', '')
                else:
                    text = ''
            else:
                # OpenAI response format
                choices = response.get('choices', [])
                if not choices:
                    raise ValueError("No choices in response")
                text = choices[0].get('message', {}).get('content', '')

            if not text:
                raise ValueError("Empty response from LLM")

            logger.info(f"LLM response length: {len(text)} chars")

            # Try to parse as JSON
            try:
                # Clean up the text - remove markdown code blocks if present
                clean_text = text.strip()

                # Handle ```json ... ``` or ``` ... ```
                if '```' in clean_text:
                    # Extract content between code blocks
                    match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', clean_text)
                    if match:
                        clean_text = match.group(1).strip()
                    else:
                        # Try removing just the first and last lines if they contain ```
                        lines = clean_text.split('\n')
                        if lines[0].strip().startswith('```'):
                            lines = lines[1:]
                        if lines and lines[-1].strip() == '```':
                            lines = lines[:-1]
                        clean_text = '\n'.join(lines)

                logger.info(f"Cleaned text for JSON parsing: {clean_text[:100]}...")
                structured = json_module.loads(clean_text)

                # Build structured response
                return {
                    'analysis': text,
                    'structured': structured,
                    'problem_summary': structured.get('problem_summary', ''),
                    'root_causes': structured.get('root_causes', []),
                    'financial_impact': structured.get('financial_impact', {}),
                    'mitigation_actions': structured.get('mitigation_actions', []),
                    'risk_level': structured.get('risk_level', 'Medium'),
                    'confidence_score': structured.get('confidence_score', 75),
                    'key_insight': structured.get('key_insight', ''),
                    'recommendations': [a['action'] for a in structured.get('mitigation_actions', [])],
                    'risk_factors': [c['cause'] for c in structured.get('root_causes', [])],
                    'model_used': self._llm_model_name or 'llm',
                    'is_mock': False
                }
            except json_module.JSONDecodeError as je:
                # Fallback to text parsing if JSON fails
                logger.warning(f"Failed to parse LLM response as JSON: {je}")
                logger.warning(f"Raw text: {text[:500]}")
                return {
                    'analysis': text,
                    'structured': None,
                    'problem_summary': 'Analysis completed - see details below',
                    'root_causes': [],
                    'financial_impact': {},
                    'mitigation_actions': [],
                    'risk_level': 'Medium',
                    'confidence_score': 70,
                    'key_insight': text[:300] if text else '',
                    'recommendations': ['Review the detailed analysis above'],
                    'risk_factors': ['See analysis for details'],
                    'model_used': self._llm_model_name or 'llm',
                    'is_mock': False
                }

        except Exception as e:
            logger.error(f"Failed to parse LLM response: {e}")
            raise

    def analyze(self, sku_data: dict) -> dict:
        """
        Perform deep analysis of SKU using LLM.

        Args:
            sku_data: Dictionary containing SKU details, metrics, and history

        Returns:
            Dictionary with analysis, recommendations, risk_factors, model_used, is_mock
        """
        # Try to use live LLM
        if self._initialize() and self._llm_deployment_id:
            try:
                prompt = self._build_prompt(sku_data)
                response = self._call_llm(prompt)
                result = self._parse_response(response)
                logger.info(f"✅ LLM analysis complete for {sku_data.get('sku_id')}")
                return result

            except Exception as e:
                logger.error(f"❌ LLM analysis failed, falling back to mock: {e}")

        # Fall back to mock analyzer
        return self._mock_analyzer.analyze(sku_data)


# Singleton instance
_llm_client: Optional[LLMClient] = None


def get_gpt_client() -> LLMClient:
    """Get or create the LLM client singleton."""
    global _llm_client
    if _llm_client is None:
        _llm_client = LLMClient()
    return _llm_client


def analyze_sku_deep(sku_data: dict) -> dict:
    """
    Main interface for deep SKU analysis.

    Args:
        sku_data: Dictionary containing all SKU information

    Returns:
        Dictionary with analysis results
    """
    client = get_gpt_client()
    start_time = time.time()
    result = client.analyze(sku_data)
    result['duration_ms'] = round((time.time() - start_time) * 1000, 1)
    result['generated_at'] = datetime.now().isoformat()
    return result


def check_gpt_available() -> Tuple[bool, Optional[str]]:
    """
    Check if LLM analysis is available.

    Returns:
        Tuple of (is_available: bool, model_name: str or None)
    """
    client = get_gpt_client()
    available = client.is_available()
    model = client._llm_model_name if available else None
    return (available, model)
