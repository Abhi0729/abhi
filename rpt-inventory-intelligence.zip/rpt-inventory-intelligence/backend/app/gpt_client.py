"""
LLM Client for deep analysis of individual SKUs via SAP AI Core.

Supports multiple LLM providers deployed in AI Core:
- Claude models (anthropic--claude-4.5-sonnet, claude-sonnet-4-5, etc.)
- GPT models (gpt-4o, gpt-4, gpt-35-turbo, gpt-5-mini, etc.)

Falls back to mock analysis when unavailable.

This creates a HYBRID AI architecture:
- SAP-RPT: Bulk scoring of all SKUs (classification + regression)
- LLM: Deep analysis of single SKU (detailed explanations, recommendations)
"""
import os
import time
import logging
import httpx
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
import json

from .config import is_aicore_configured, get_settings, get_aicore_credentials

logger = logging.getLogger(__name__)

# Model patterns to look for (in order of preference)
# Format: (pattern_to_match, provider_type)
LLM_MODEL_PATTERNS = [
    ('claude', 'anthropic'),  # Prefer Claude - works reliably
    ('anthropic', 'anthropic'),
    ('gpt-4o', 'openai'),
    ('gpt-4', 'openai'),
    ('gpt-5', 'openai'),
    ('gpt-35', 'openai'),
    ('gpt-3.5', 'openai'),
]


class MockGPTAnalyzer:
    """
    Mock analyzer that generates executive-level analysis when AI Core is unavailable.
    Uses professional terminology suitable for C-level presentations.
    """

    def analyze(self, sku_data: dict) -> dict:
        """Generate professional mock analysis based on SKU data."""
        logger.warning("⚠️ Using mock LLM analyzer — AI Core LLM not available")

        priority = sku_data.get('recount_priority', 'MEDIUM')
        variance = sku_data.get('avg_variance_pct', 0)
        trend = sku_data.get('variance_trend', 'stable')
        sku_id = sku_data.get('sku_id', 'Unknown')
        category = sku_data.get('category', 'Unknown')
        unit_cost = sku_data.get('unit_cost', 0)
        days_since = sku_data.get('days_since_last_count', 0)
        plant = sku_data.get('plant', 'Unknown')

        # Calculate estimated financial impact
        estimated_units_affected = int(abs(variance) * 10)  # Rough estimate
        value_at_risk = estimated_units_affected * unit_cost

        if priority == 'HIGH':
            problem_summary = f"Critical inventory control deviation detected for {category} asset {sku_id} at {plant} facility, with {variance:.1f}% mean variance rate representing significant operational and financial exposure."

            root_causes = [
                {
                    "cause": "Transaction Synchronization Latency",
                    "description": f"Material movements are not being captured in real-time, creating systematic discrepancies between physical inventory and ERP book quantities at the {plant} facility."
                },
                {
                    "cause": "Process Compliance Degradation",
                    "description": f"Standard operating procedures for {category} inventory handling show evidence of deviation, particularly in receiving verification and put-away confirmation workflows."
                },
                {
                    "cause": "Master Data Integrity Gap",
                    "description": f"Unit of measure configurations or storage location mappings may contain inconsistencies affecting accurate quantity tracking for this SKU classification."
                }
            ]

            financial_impact = {
                "estimated_value_at_risk": f"${value_at_risk:,.2f} - ${value_at_risk * 1.5:,.2f}",
                "impact_description": f"Based on {variance:.1f}% variance and ${unit_cost:.2f} unit valuation, exposure includes potential write-offs, fulfillment failures, and working capital inefficiency."
            }

            mitigation_actions = [
                {
                    "action": "Executive-Sponsored Physical Verification",
                    "priority": "Immediate",
                    "description": "Commission supervised wall-to-wall count with dual verification protocol and real-time variance documentation."
                },
                {
                    "action": "Transaction Audit and Reconciliation",
                    "priority": "Short-term",
                    "description": "Conduct forensic analysis of all material movements, adjustments, and transfer postings over the trailing 30-day period."
                },
                {
                    "action": "Process Re-engineering Initiative",
                    "priority": "Long-term",
                    "description": f"Implement enhanced inventory control framework for {category} products including barcode scanning validation and automated discrepancy alerts."
                }
            ]

            risk_level = "Critical" if variance > 15 or trend == 'worsening' else "High"
            confidence_score = 92
            key_insight = f"Immediate executive intervention recommended. The {trend} trajectory of variance in this high-value {category} SKU indicates systemic control weakness requiring cross-functional remediation."

        elif priority == 'MEDIUM':
            problem_summary = f"Elevated inventory variance identified for {category} SKU {sku_id}, indicating process optimization opportunity with manageable risk exposure."

            root_causes = [
                {
                    "cause": "Cycle Count Timing Discrepancy",
                    "description": f"Verification frequency may be insufficient for this {category} velocity profile, allowing variance accumulation between count cycles."
                },
                {
                    "cause": "Operational Workflow Variance",
                    "description": "Minor deviations in standard handling procedures across shifts or operators contributing to incremental accuracy erosion."
                },
                {
                    "cause": "System Configuration Optimization",
                    "description": "Tolerance thresholds and automated alert parameters may require recalibration for this product classification."
                }
            ]

            financial_impact = {
                "estimated_value_at_risk": f"${value_at_risk:,.2f}",
                "impact_description": f"Moderate exposure with {variance:.1f}% variance. Addressable through standard continuous improvement protocols without significant capital investment."
            }

            mitigation_actions = [
                {
                    "action": "Prioritized Cycle Count Inclusion",
                    "priority": "Immediate",
                    "description": "Escalate to next scheduled verification cycle with enhanced documentation requirements."
                },
                {
                    "action": "Root Cause Investigation",
                    "priority": "Short-term",
                    "description": "Analyze transaction patterns and operator-specific variance rates to identify targeted improvement opportunities."
                },
                {
                    "action": "Control Parameter Optimization",
                    "priority": "Long-term",
                    "description": f"Review and adjust inventory control thresholds for {category} product family based on value and velocity characteristics."
                }
            ]

            risk_level = "Medium"
            confidence_score = 85
            key_insight = f"Proactive monitoring recommended. This {category} SKU shows variance patterns addressable through operational refinement without escalation to crisis management."

        else:
            problem_summary = f"Inventory control metrics for {category} SKU {sku_id} are operating within acceptable tolerance bands, demonstrating effective inventory management practices."

            root_causes = [
                {
                    "cause": "Operational Excellence Baseline",
                    "description": f"Current {variance:.1f}% variance rate reflects mature inventory control processes and effective standard operating procedures."
                },
                {
                    "cause": "Consistent Process Adherence",
                    "description": "Verification activities and material handling workflows are being executed with appropriate rigor and documentation."
                },
                {
                    "cause": "Effective System Integration",
                    "description": "ERP transaction capture and physical inventory movements are well-synchronized for this SKU classification."
                }
            ]

            financial_impact = {
                "estimated_value_at_risk": f"< ${max(value_at_risk, 100):,.2f}",
                "impact_description": "Minimal exposure. Current variance levels represent acceptable operational tolerance with no material financial impact."
            }

            mitigation_actions = [
                {
                    "action": "Maintain Standard Verification Cadence",
                    "priority": "Long-term",
                    "description": "Continue current cycle counting schedule and monitoring protocols."
                },
                {
                    "action": "Best Practice Documentation",
                    "priority": "Long-term",
                    "description": f"Document successful control practices for this {category} SKU as reference model for similar product classifications."
                },
                {
                    "action": "Continuous Monitoring",
                    "priority": "Long-term",
                    "description": "Maintain dashboard visibility to detect any emerging variance trends requiring intervention."
                }
            ]

            risk_level = "Low"
            confidence_score = 88
            key_insight = f"Exemplary inventory control performance. Consider this {category} SKU's management approach as a benchmark for operational excellence initiatives."

        return {
            'problem_summary': problem_summary,
            'root_causes': root_causes,
            'financial_impact': financial_impact,
            'mitigation_actions': mitigation_actions,
            'risk_level': risk_level,
            'confidence_score': confidence_score,
            'key_insight': key_insight,
            'analysis': f"## Executive Summary\n\n{problem_summary}\n\n### Risk Assessment: {risk_level}",
            'recommendations': [a['action'] for a in mitigation_actions],
            'risk_factors': [c['cause'] for c in root_causes],
            'model_used': 'mock-analyzer',
            'is_mock': True
        }


class LLMClient:
    """
    Client for LLM analysis via SAP AI Core.
    Auto-detects available LLM deployments (Claude or GPT) or uses configured deployment ID.
    """

    def __init__(self):
        self._mock_analyzer = MockGPTAnalyzer()
        self._token = None
        self._token_expires = 0
        self._llm_deployment_id = None
        self._llm_model_name = None
        self._llm_provider = None  # 'anthropic' or 'openai'
        self._initialized = False

    def _get_token(self) -> Optional[str]:
        """Get OAuth token for AI Core."""
        creds = get_aicore_credentials()
        if not creds:
            return None

        # Check if token is still valid
        if self._token and time.time() < self._token_expires - 60:
            return self._token

        try:
            auth_url = creds['auth_url'].rstrip('/') + '/oauth/token'
            response = httpx.post(
                auth_url,
                data={
                    'grant_type': 'client_credentials',
                    'client_id': creds['client_id'],
                    'client_secret': creds['client_secret'],
                },
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                timeout=30.0
            )
            response.raise_for_status()
            data = response.json()
            self._token = data['access_token']
            self._token_expires = time.time() + data.get('expires_in', 3600)
            return self._token
        except Exception as e:
            logger.error(f"Failed to get AI Core token: {e}")
            return None

    def _auto_detect_llm_deployment(self) -> Optional[Tuple[str, str, str]]:
        """
        Auto-detect LLM deployment from AI Core.
        Returns (deployment_id, model_name, provider) or None.
        """
        try:
            from ai_core_sdk.ai_core_v2_client import AICoreV2Client

            creds = get_aicore_credentials()
            if not creds:
                return None

            client = AICoreV2Client(
                base_url=creds['base_url'].rstrip('/') + '/v2',
                auth_url=creds['auth_url'].rstrip('/') + '/oauth/token',
                client_id=creds['client_id'],
                client_secret=creds['client_secret'],
                resource_group=creds['resource_group']
            )

            deployments = client.deployment.query()

            # Check each pattern in order of preference
            for pattern, provider in LLM_MODEL_PATTERNS:
                for d in deployments.resources:
                    if str(d.status) != 'Status.RUNNING':
                        continue

                    details = d.details or {}
                    resources = details.get('resources', {})
                    backend = resources.get('backend_details', {})
                    model = backend.get('model', {})
                    model_name = model.get('name', '').lower()

                    if pattern in model_name:
                        logger.info(f"✅ Auto-detected LLM deployment: {d.id} ({model_name}, {provider})")
                        return (d.id, model_name, provider)

            logger.warning("⚠️ No LLM deployment found in AI Core")
            return None

        except Exception as e:
            logger.error(f"Failed to auto-detect LLM deployment: {e}")
            return None

    def _initialize(self) -> bool:
        """Initialize the LLM client, detecting deployment if needed."""
        if self._initialized:
            return self._llm_deployment_id is not None

        self._initialized = True

        if not is_aicore_configured():
            logger.warning("⚠️ AI Core not configured for LLM")
            return False

        settings = get_settings()

        # Check if deployment ID is configured
        if settings.gpt_deployment_id:
            self._llm_deployment_id = settings.gpt_deployment_id
            # Determine provider from deployment
            result = self._auto_detect_llm_deployment()
            if result:
                # Use auto-detected info if available
                for d_id, name, provider in [result]:
                    if d_id == settings.gpt_deployment_id:
                        self._llm_model_name = name
                        self._llm_provider = provider
                        break
            # Default to anthropic (Claude) since GPT-5-mini has issues
            if not self._llm_provider:
                self._llm_model_name = 'configured-llm'
                self._llm_provider = 'anthropic'  # Default to Anthropic format
            logger.info(f"✅ Using configured LLM deployment: {self._llm_deployment_id} ({self._llm_provider})")
            return True

        # Auto-detect LLM deployment
        result = self._auto_detect_llm_deployment()
        if result:
            self._llm_deployment_id, self._llm_model_name, self._llm_provider = result
            return True

        return False

    def is_available(self) -> bool:
        """Check if LLM analysis is available."""
        return self._initialize()

    def _build_prompt(self, sku_data: dict) -> str:
        """Build the analysis prompt for LLM with executive-level professional language."""
        # Format history table
        history = sku_data.get('history', [])[:10]
        history_lines = []
        for h in history:
            variance = ((h.get('counted_qty', 0) - h.get('book_qty', 0)) / max(h.get('book_qty', 1), 1)) * 100
            history_lines.append(
                f"| {h.get('count_date', 'N/A')} | {h.get('book_qty', 0)} | {h.get('counted_qty', 0)} | {variance:+.1f}% | {h.get('counted_by', 'N/A')} |"
            )

        history_table = "| Date | Book Qty | Counted | Variance | Counted By |\n|------|----------|---------|----------|------------|\n"
        history_table += "\n".join(history_lines) if history_lines else "| No recent counts available |"

        # Calculate specific metrics for context
        variance_pct = sku_data.get('avg_variance_pct', 0)
        unit_cost = sku_data.get('unit_cost', 0)
        trend = sku_data.get('variance_trend', 'stable')
        days_since = sku_data.get('days_since_last_count', 0)
        category = sku_data.get('category', 'Unknown')
        priority = sku_data.get('recount_priority', 'Unknown')

        prompt = f"""You are a Senior Supply Chain Analytics Consultant presenting findings to C-level executives and global operations leaders. Your analysis must be precise, data-driven, and use professional business terminology.

CRITICAL INSTRUCTIONS:
1. Provide SPECIFIC analysis based on the ACTUAL data patterns shown below - do NOT use generic templates
2. Reference the ACTUAL variance percentages, trends, and count history in your analysis
3. Use executive-level business language suitable for board presentations
4. Quantify financial impacts using the provided unit cost data
5. Each root cause and action must be DISTINCT and SPECIFIC to this SKU's situation

## SKU Profile
- **Asset Identifier**: {sku_data.get('sku_id', 'Unknown')}
- **Product Description**: {sku_data.get('description', 'Unknown')}
- **Product Category**: {category}
- **Facility Location**: {sku_data.get('plant', 'Unknown')}
- **ERP Source**: {sku_data.get('source_system', 'Unknown')}
- **Unit Valuation**: ${unit_cost:.2f}

## Current Risk Assessment
- **Priority Classification**: {priority}
- **Urgency Index**: {sku_data.get('urgency_score', 0)}/100
- **Mean Variance Rate**: {variance_pct:.1f}%
- **Variance Trajectory**: {trend}
- **Count Recency**: {days_since} days since last verification

## Historical Count Data
{history_table}

ANALYSIS REQUIREMENTS:
- If variance is HIGH (>{10}%): Focus on systemic process failures, potential shrinkage, or transaction integrity issues
- If variance is MEDIUM (5-10%): Examine timing discrepancies, unit-of-measure inconsistencies, or location accuracy
- If variance is LOW (<5%): Highlight operational excellence while noting any emerging patterns
- Consider the TREND direction: {"Escalating risk requiring intervention" if trend == 'worsening' else "Stabilizing pattern" if trend == 'improving' else "Consistent performance"}
- Factor in count recency: {"Stale data - verification urgency elevated" if days_since > 14 else "Recent verification - data confidence high"}

Respond with this exact JSON structure (no markdown, no code blocks, just raw JSON):
{{
  "problem_summary": "Executive summary of the inventory control issue - be specific to THIS SKU's {variance_pct:.1f}% variance and {trend} trend",
  "root_causes": [
    {{"cause": "Primary Contributing Factor", "description": "Specific operational or systemic issue causing this SKU's variance pattern"}},
    {{"cause": "Secondary Contributing Factor", "description": "Additional process or data integrity factor"}},
    {{"cause": "Tertiary Contributing Factor", "description": "Environmental or procedural consideration"}}
  ],
  "financial_impact": {{
    "estimated_value_at_risk": "Calculate based on ${unit_cost:.2f} unit cost and variance magnitude",
    "impact_description": "Quantified business impact including working capital, fulfillment risk, and reporting implications"
  }},
  "mitigation_actions": [
    {{"action": "Strategic Initiative Title", "priority": "Immediate", "description": "Specific corrective action with measurable outcome"}},
    {{"action": "Tactical Improvement", "priority": "Short-term", "description": "Process enhancement recommendation"}},
    {{"action": "Systemic Enhancement", "priority": "Long-term", "description": "Structural or technology improvement"}}
  ],
  "risk_level": "{"Critical" if variance_pct > 15 or (trend == "worsening" and variance_pct > 8) else "High" if variance_pct > 10 or trend == "worsening" else "Medium" if variance_pct > 5 else "Low"}",
  "confidence_score": 85,
  "key_insight": "Strategic recommendation for executive decision-making - specific to this {category} SKU"
}}"""

        return prompt

    def _call_llm(self, prompt: str) -> dict:
        """Call LLM via AI Core inference API."""
        creds = get_aicore_credentials()
        token = self._get_token()

        if not token or not creds or not self._llm_deployment_id:
            raise Exception("LLM client not properly initialized")

        base_url = creds['base_url'].rstrip('/')

        if self._llm_provider == 'anthropic':
            # Use Anthropic/Claude format with /invoke endpoint
            url = f"{base_url}/v2/inference/deployments/{self._llm_deployment_id}/invoke"
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 1500,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }
        else:
            # Use OpenAI format with /v1/chat/completions endpoint
            url = f"{base_url}/v2/inference/deployments/{self._llm_deployment_id}/v1/chat/completions"
            request_body = {
                "messages": [
                    {
                        "role": "system",
                        "content": "You are an expert inventory analyst helping warehouse managers understand and resolve inventory discrepancies."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "max_completion_tokens": 1500
            }

        logger.info(f"Calling LLM ({self._llm_provider}) at {url}")

        response = httpx.post(
            url,
            json=request_body,
            headers={
                'Authorization': f'Bearer {token}',
                'AI-Resource-Group': creds['resource_group'],
                'Content-Type': 'application/json',
            },
            timeout=120.0
        )

        if response.status_code != 200:
            logger.error(f"LLM API error: {response.status_code} - {response.text}")
            response.raise_for_status()

        result = response.json()
        return result

    def _parse_response(self, response: dict) -> dict:
        """Parse LLM response into structured format."""
        import json as json_module
        try:
            if self._llm_provider == 'anthropic':
                # Anthropic response format
                content = response.get('content', [])
                if content and len(content) > 0:
                    text = content[0].get('text', '')
                else:
                    text = ''
            else:
                # OpenAI response format
                choices = response.get('choices', [])
                if not choices:
                    raise ValueError("No choices in response")
                text = choices[0].get('message', {}).get('content', '')

            if not text:
                raise ValueError("Empty response from LLM")

            # Try to parse as JSON
            try:
                # Clean up the text - remove markdown code blocks if present
                clean_text = text.strip()
                if clean_text.startswith('```'):
                    # Remove markdown code block
                    lines = clean_text.split('\n')
                    clean_text = '\n'.join(lines[1:-1] if lines[-1] == '```' else lines[1:])

                structured = json_module.loads(clean_text)

                # Build structured response
                return {
                    'analysis': text,
                    'structured': structured,
                    'problem_summary': structured.get('problem_summary', ''),
                    'root_causes': structured.get('root_causes', []),
                    'financial_impact': structured.get('financial_impact', {}),
                    'mitigation_actions': structured.get('mitigation_actions', []),
                    'risk_level': structured.get('risk_level', 'Medium'),
                    'confidence_score': structured.get('confidence_score', 75),
                    'key_insight': structured.get('key_insight', ''),
                    'recommendations': [a['action'] for a in structured.get('mitigation_actions', [])],
                    'risk_factors': [c['cause'] for c in structured.get('root_causes', [])],
                    'model_used': self._llm_model_name or 'llm',
                    'is_mock': False
                }
            except json_module.JSONDecodeError:
                # Fallback to text parsing if JSON fails
                logger.warning("Failed to parse LLM response as JSON, using text fallback")
                return {
                    'analysis': text,
                    'structured': None,
                    'problem_summary': 'Analysis completed',
                    'root_causes': [],
                    'financial_impact': {},
                    'mitigation_actions': [],
                    'risk_level': 'Medium',
                    'confidence_score': 70,
                    'key_insight': text[:200] if text else '',
                    'recommendations': ['Review the detailed analysis above'],
                    'risk_factors': ['See analysis for details'],
                    'model_used': self._llm_model_name or 'llm',
                    'is_mock': False
                }

        except Exception as e:
            logger.error(f"Failed to parse LLM response: {e}")
            raise

    def analyze(self, sku_data: dict) -> dict:
        """
        Perform deep analysis of SKU using LLM.

        Args:
            sku_data: Dictionary containing SKU details, metrics, and history

        Returns:
            Dictionary with analysis, recommendations, risk_factors, model_used, is_mock
        """
        # Try to use live LLM
        if self._initialize() and self._llm_deployment_id:
            try:
                prompt = self._build_prompt(sku_data)
                response = self._call_llm(prompt)
                result = self._parse_response(response)
                logger.info(f"✅ LLM analysis complete for {sku_data.get('sku_id')}")
                return result

            except Exception as e:
                logger.error(f"❌ LLM analysis failed, falling back to mock: {e}")

        # Fall back to mock analyzer
        return self._mock_analyzer.analyze(sku_data)


# Singleton instance
_llm_client: Optional[LLMClient] = None


def get_gpt_client() -> LLMClient:
    """Get or create the LLM client singleton."""
    global _llm_client
    if _llm_client is None:
        _llm_client = LLMClient()
    return _llm_client


def analyze_sku_deep(sku_data: dict) -> dict:
    """
    Main interface for deep SKU analysis.

    Args:
        sku_data: Dictionary containing all SKU information

    Returns:
        Dictionary with analysis results
    """
    client = get_gpt_client()
    start_time = time.time()
    result = client.analyze(sku_data)
    result['duration_ms'] = round((time.time() - start_time) * 1000, 1)
    result['generated_at'] = datetime.now().isoformat()
    return result


def check_gpt_available() -> Tuple[bool, Optional[str]]:
    """
    Check if LLM analysis is available.

    Returns:
        Tuple of (is_available: bool, model_name: str or None)
    """
    client = get_gpt_client()
    available = client.is_available()
    model = client._llm_model_name if available else None
    return (available, model)
