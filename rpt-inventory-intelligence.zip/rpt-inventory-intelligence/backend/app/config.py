"""Configuration module for AI Core credentials and application settings."""
import os
import json
from pathlib import Path
from functools import lru_cache
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Database
    database_url: str = "sqlite:///./inventory.db"

    # AI Core - Service Key Path (Option 1)
    aicore_service_key_path: Optional[str] = None

    # AI Core - Discrete Variables (Option 2)
    aicore_auth_url: Optional[str] = None
    aicore_client_id: Optional[str] = None
    aicore_client_secret: Optional[str] = None
    aicore_base_url: Optional[str] = None
    aicore_resource_group: str = "default"

    # SAP-RPT Deployment
    rpt_deployment_id: Optional[str] = None
    rpt_model_name: str = "sap-rpt-1-small"

    # Cache settings
    prediction_cache_ttl_seconds: int = 300

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


def load_service_key(path: str) -> dict:
    """Load AI Core service key from JSON file."""
    key_path = Path(path)
    if not key_path.exists():
        raise FileNotFoundError(f"Service key not found at: {path}")

    with open(key_path, "r") as f:
        return json.load(f)


def get_aicore_credentials() -> Optional[dict]:
    """
    Get AI Core credentials from either service key or environment variables.
    Returns None if no valid credentials are configured.
    """
    settings = get_settings()

    # Try Option 1: Service key JSON file
    if settings.aicore_service_key_path:
        try:
            key_data = load_service_key(settings.aicore_service_key_path)
            return {
                "auth_url": key_data.get("url") or key_data.get("uaa", {}).get("url"),
                "client_id": key_data.get("clientid") or key_data.get("uaa", {}).get("clientid"),
                "client_secret": key_data.get("clientsecret") or key_data.get("uaa", {}).get("clientsecret"),
                "base_url": key_data.get("serviceurls", {}).get("AI_API_URL") or key_data.get("url"),
                "resource_group": settings.aicore_resource_group,
            }
        except (FileNotFoundError, json.JSONDecodeError, KeyError) as e:
            print(f"⚠️  Failed to load service key: {e}")
            return None

    # Try Option 2: Discrete environment variables
    if all([
        settings.aicore_auth_url,
        settings.aicore_client_id,
        settings.aicore_client_secret,
        settings.aicore_base_url,
    ]):
        return {
            "auth_url": settings.aicore_auth_url,
            "client_id": settings.aicore_client_id,
            "client_secret": settings.aicore_client_secret,
            "base_url": settings.aicore_base_url,
            "resource_group": settings.aicore_resource_group,
        }

    return None


def is_aicore_configured() -> bool:
    """Check if AI Core credentials are configured."""
    return get_aicore_credentials() is not None


def configure_aicore_env():
    """
    Set environment variables for the generative-ai-hub-sdk.
    The SDK reads from standard env vars.
    """
    creds = get_aicore_credentials()
    if not creds:
        return False

    # Set env vars that the SDK expects
    os.environ["AICORE_AUTH_URL"] = creds["auth_url"]
    os.environ["AICORE_CLIENT_ID"] = creds["client_id"]
    os.environ["AICORE_CLIENT_SECRET"] = creds["client_secret"]
    os.environ["AICORE_BASE_URL"] = creds["base_url"]
    os.environ["AICORE_RESOURCE_GROUP"] = creds["resource_group"]

    return True
