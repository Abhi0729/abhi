"""
Physical Inventory Intelligence - FastAPI Application

Zero-shot SAP-RPT scoring for physical inventory recount prioritization.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
import logging

from .db import init_db, get_db
from .config import is_aicore_configured
from .models import HealthResponse
from .rpt_client import check_aicore_reachable, load_predictions_from_cache
from .routers import skus_router, recounts_router, kpis_router

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Physical Inventory Intelligence",
    description="Zero-shot SAP-RPT scoring for physical inventory recount prioritization",
    version="1.0.0",
)

# CORS middleware - allow all origins for flexibility across deployments
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    """Initialize database on startup."""
    logger.info("🚀 Starting Physical Inventory Intelligence...")
    init_db()

    if is_aicore_configured():
        logger.info("✅ AI Core credentials configured - SAP-RPT live mode available")
    else:
        logger.warning("⚠️ AI Core credentials not found - running in mock mode")


@app.get("/api/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    """
    Health check endpoint.
    Reports whether running in live SAP-RPT mode or mock mode.
    """
    # Check AI Core status
    ai_core_reachable = check_aicore_reachable()

    # Check database
    db_ok = True
    try:
        with get_db() as conn:
            conn.cursor().execute("SELECT 1")
    except Exception:
        db_ok = False

    # Get last prediction time
    _, is_mock, last_predicted = load_predictions_from_cache()

    return HealthResponse(
        rpt_mode="live" if ai_core_reachable else "mock",
        ai_core_reachable=ai_core_reachable,
        database_ok=db_ok,
        last_prediction_time=last_predicted
    )


# Register routers
app.include_router(skus_router)
app.include_router(recounts_router)
app.include_router(kpis_router)


@app.get("/", tags=["Root"])
async def root():
    """Root endpoint with API info."""
    return {
        "name": "Physical Inventory Intelligence",
        "version": "1.0.0",
        "description": "Zero-shot SAP-RPT scoring for physical inventory recount prioritization",
        "docs": "/docs",
        "health": "/api/health"
    }
