"""
Pattern Engine for computing SKU-level metrics from PID history.

Calculates:
- avg_variance_pct: trailing 14-day mean variance
- recount_frequency_7d: count of PIDs in trailing 7 days
- days_since_last_count: days since most recent PID
- variance_trend: worsening/stable/improving based on period comparison
"""
import pandas as pd
from datetime import date, timedelta
from typing import Optional

from .db import get_db


def load_pid_history(as_of_date: Optional[date] = None) -> pd.DataFrame:
    """Load PID documents from database into DataFrame."""
    if as_of_date is None:
        as_of_date = date.today()

    with get_db() as conn:
        query = """
            SELECT
                pid_id,
                sku_id,
                source_system,
                count_date,
                book_qty,
                counted_qty,
                counted_by
            FROM pid_documents
            WHERE count_date <= ?
            ORDER BY count_date DESC
        """
        df = pd.read_sql_query(query, conn, params=[as_of_date.isoformat()])

    if not df.empty:
        df['count_date'] = pd.to_datetime(df['count_date']).dt.date
        # Calculate variance percentage
        df['variance_pct'] = ((df['counted_qty'] - df['book_qty']) / df['book_qty'] * 100).round(2)

    return df


def compute_sku_patterns(as_of_date: Optional[date] = None) -> pd.DataFrame:
    """
    Compute pattern metrics for each SKU.

    Returns DataFrame with columns:
    - sku_id
    - avg_variance_pct (trailing 14-day mean)
    - recount_frequency_7d (PIDs in trailing 7 days)
    - days_since_last_count
    - variance_trend (worsening/stable/improving)
    """
    if as_of_date is None:
        as_of_date = date.today()

    df = load_pid_history(as_of_date)

    if df.empty:
        return pd.DataFrame(columns=[
            'sku_id', 'avg_variance_pct', 'recount_frequency_7d',
            'days_since_last_count', 'variance_trend'
        ])

    # Date boundaries
    trailing_14d_start = as_of_date - timedelta(days=14)
    trailing_7d_start = as_of_date - timedelta(days=7)
    prior_14d_start = as_of_date - timedelta(days=28)
    prior_14d_end = as_of_date - timedelta(days=14)

    # Get all unique SKUs
    all_skus = df['sku_id'].unique()
    results = []

    for sku_id in all_skus:
        sku_df = df[df['sku_id'] == sku_id].copy()

        # avg_variance_pct: trailing 14-day mean (absolute variance)
        trailing_14d = sku_df[sku_df['count_date'] >= trailing_14d_start]
        avg_variance = trailing_14d['variance_pct'].abs().mean() if not trailing_14d.empty else 0.0

        # recount_frequency_7d: count of PIDs in trailing 7 days
        trailing_7d = sku_df[sku_df['count_date'] >= trailing_7d_start]
        recount_freq = len(trailing_7d)

        # days_since_last_count
        if not sku_df.empty:
            last_count = max(sku_df['count_date'])
            days_since = (as_of_date - last_count).days
        else:
            days_since = 999

        # variance_trend: compare trailing 14d to prior 14d
        prior_14d = sku_df[
            (sku_df['count_date'] >= prior_14d_start) &
            (sku_df['count_date'] < prior_14d_end)
        ]

        if not trailing_14d.empty and not prior_14d.empty:
            current_avg = trailing_14d['variance_pct'].abs().mean()
            prior_avg = prior_14d['variance_pct'].abs().mean()
            diff = current_avg - prior_avg

            if diff > 3:
                trend = "worsening"
            elif diff < -3:
                trend = "improving"
            else:
                trend = "stable"
        else:
            # Not enough history for trend
            trend = "stable"

        results.append({
            'sku_id': sku_id,
            'avg_variance_pct': round(avg_variance, 2),
            'recount_frequency_7d': recount_freq,
            'days_since_last_count': days_since,
            'variance_trend': trend
        })

    return pd.DataFrame(results)


def save_patterns_to_db(patterns_df: pd.DataFrame, pattern_date: Optional[date] = None):
    """Save computed patterns to database."""
    if pattern_date is None:
        pattern_date = date.today()

    if patterns_df.empty:
        return

    with get_db() as conn:
        cursor = conn.cursor()

        # Clear existing patterns for this date
        cursor.execute(
            "DELETE FROM daily_count_pattern WHERE pattern_date = ?",
            [pattern_date.isoformat()]
        )

        # Insert new patterns
        for _, row in patterns_df.iterrows():
            cursor.execute("""
                INSERT INTO daily_count_pattern
                (sku_id, pattern_date, avg_variance_pct, recount_frequency_7d,
                 days_since_last_count, variance_trend)
                VALUES (?, ?, ?, ?, ?, ?)
            """, [
                row['sku_id'],
                pattern_date.isoformat(),
                row['avg_variance_pct'],
                row['recount_frequency_7d'],
                row['days_since_last_count'],
                row['variance_trend']
            ])

        conn.commit()

    print(f"✅ Saved patterns for {len(patterns_df)} SKUs (date: {pattern_date})")


def load_patterns_from_db(pattern_date: Optional[date] = None) -> pd.DataFrame:
    """Load patterns from database."""
    if pattern_date is None:
        pattern_date = date.today()

    with get_db() as conn:
        query = """
            SELECT sku_id, avg_variance_pct, recount_frequency_7d,
                   days_since_last_count, variance_trend
            FROM daily_count_pattern
            WHERE pattern_date = ?
        """
        df = pd.read_sql_query(query, conn, params=[pattern_date.isoformat()])

    return df


def get_sku_patterns_with_master() -> pd.DataFrame:
    """
    Get patterns joined with SKU master data.
    Returns the feature table ready for RPT scoring.
    """
    with get_db() as conn:
        query = """
            SELECT
                m.sku_id,
                m.description,
                m.category,
                m.source_system,
                m.plant,
                m.unit_cost,
                COALESCE(p.avg_variance_pct, 0) as avg_variance_pct,
                COALESCE(p.recount_frequency_7d, 0) as recount_frequency_7d,
                COALESCE(p.days_since_last_count, 999) as days_since_last_count,
                COALESCE(p.variance_trend, 'stable') as variance_trend
            FROM sku_master m
            LEFT JOIN daily_count_pattern p ON m.sku_id = p.sku_id
            WHERE p.pattern_date = (SELECT MAX(pattern_date) FROM daily_count_pattern)
               OR p.pattern_date IS NULL
        """
        df = pd.read_sql_query(query, conn)

    return df


def refresh_patterns(as_of_date: Optional[date] = None) -> pd.DataFrame:
    """Compute and save fresh patterns."""
    if as_of_date is None:
        as_of_date = date.today()

    print(f"🔄 Computing patterns as of {as_of_date}...")
    patterns = compute_sku_patterns(as_of_date)
    save_patterns_to_db(patterns, as_of_date)
    return patterns


if __name__ == "__main__":
    patterns = refresh_patterns()
    print(patterns.head(20))
