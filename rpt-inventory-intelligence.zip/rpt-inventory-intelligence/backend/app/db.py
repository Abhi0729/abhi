"""Database setup and connection management."""
import sqlite3
from pathlib import Path
from contextlib import contextmanager
from typing import Generator

DATABASE_PATH = Path(__file__).parent.parent / "inventory.db"


def get_connection() -> sqlite3.Connection:
    """Get a database connection with row factory enabled."""
    conn = sqlite3.connect(str(DATABASE_PATH))
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def get_db() -> Generator[sqlite3.Connection, None, None]:
    """Context manager for database connections."""
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Initialize database schema."""
    with get_db() as conn:
        cursor = conn.cursor()

        # SKU Master table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sku_master (
                sku_id TEXT PRIMARY KEY,
                description TEXT NOT NULL,
                category TEXT NOT NULL,
                source_system TEXT NOT NULL CHECK (source_system IN ('ECC', 'S4HANA')),
                plant TEXT NOT NULL,
                unit_cost REAL NOT NULL
            )
        """)

        # Physical Inventory Documents table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pid_documents (
                pid_id TEXT PRIMARY KEY,
                sku_id TEXT NOT NULL,
                source_system TEXT NOT NULL CHECK (source_system IN ('ECC', 'S4HANA')),
                count_date DATE NOT NULL,
                book_qty REAL NOT NULL,
                counted_qty REAL NOT NULL,
                counted_by TEXT NOT NULL,
                FOREIGN KEY (sku_id) REFERENCES sku_master(sku_id)
            )
        """)

        # Daily Count Pattern table (derived metrics)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_count_pattern (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sku_id TEXT NOT NULL,
                pattern_date DATE NOT NULL,
                avg_variance_pct REAL,
                recount_frequency_7d INTEGER,
                days_since_last_count INTEGER,
                variance_trend TEXT CHECK (variance_trend IN ('worsening', 'stable', 'improving')),
                FOREIGN KEY (sku_id) REFERENCES sku_master(sku_id),
                UNIQUE(sku_id, pattern_date)
            )
        """)

        # Predictions cache table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS predictions_cache (
                sku_id TEXT PRIMARY KEY,
                recount_priority TEXT NOT NULL,
                urgency_score REAL NOT NULL,
                confidence REAL NOT NULL,
                predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_mock INTEGER DEFAULT 0,
                FOREIGN KEY (sku_id) REFERENCES sku_master(sku_id)
            )
        """)

        # Create indexes for common queries
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_pid_sku ON pid_documents(sku_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_pid_date ON pid_documents(count_date)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_pattern_sku ON daily_count_pattern(sku_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_pattern_date ON daily_count_pattern(pattern_date)")

        conn.commit()


def clear_db():
    """Clear all data from database tables."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM predictions_cache")
        cursor.execute("DELETE FROM daily_count_pattern")
        cursor.execute("DELETE FROM pid_documents")
        cursor.execute("DELETE FROM sku_master")
        conn.commit()


def drop_db():
    """Drop all tables."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("DROP TABLE IF EXISTS predictions_cache")
        cursor.execute("DROP TABLE IF EXISTS daily_count_pattern")
        cursor.execute("DROP TABLE IF EXISTS pid_documents")
        cursor.execute("DROP TABLE IF EXISTS sku_master")
        conn.commit()
