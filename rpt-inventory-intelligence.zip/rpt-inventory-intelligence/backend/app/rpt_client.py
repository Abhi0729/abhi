"""
SAP-RPT Client for zero-shot classification and regression predictions.

Uses the AI Core SDK to call SAP-RPT models deployed in AI Core.
Falls back to a mock scorer when AI Core credentials are not available.

SAP-RPT supports:
- Up to 512 rows per request
- Up to 10 columns per request
- Zero-shot classification and regression (no training needed)
"""
import os
import time
import logging
import httpx
from datetime import datetime
from typing import Optional, Tuple
import pandas as pd
import numpy as np

from .config import is_aicore_configured, get_settings, get_aicore_credentials
from .db import get_db

logger = logging.getLogger(__name__)

# Constants
MAX_ROWS_PER_REQUEST = 512
MAX_COLUMNS = 10
CACHE_TTL_SECONDS = 300


class MockRPTScorer:
    """
    Mock scorer that mimics SAP-RPT output when AI Core is unavailable.
    Uses simple heuristics for demo purposes.
    """

    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate mock predictions based on feature heuristics.

        Heuristic logic:
        - HIGH priority: avg_variance > 10% OR (worsening trend AND variance > 5%)
        - MEDIUM priority: variance 5-10% OR (any negative trend)
        - LOW priority: everything else

        urgency_score: weighted combination of variance and trend
        """
        logger.warning("⚠️ Using mock RPT scorer — AI Core credentials not found")

        results = []
        for _, row in df.iterrows():
            variance = abs(row.get('avg_variance_pct', 0))
            trend = row.get('variance_trend', 'stable')
            days_since = row.get('days_since_last_count', 0)
            freq = row.get('recount_frequency_7d', 0)

            # Determine priority
            if variance > 10 or (trend == 'worsening' and variance > 5):
                priority = "HIGH"
                base_score = 70 + min(variance, 30)  # 70-100
            elif variance > 5 or trend == 'worsening':
                priority = "MEDIUM"
                base_score = 40 + variance * 2  # 40-70ish
            else:
                priority = "LOW"
                base_score = max(10, variance * 3)  # 10-40ish

            # Adjust for trend
            if trend == 'worsening':
                base_score += 10
            elif trend == 'improving':
                base_score -= 5

            # Adjust for recency
            if days_since > 14:
                base_score += 5  # Penalize stale counts

            # Clamp to 0-100
            urgency_score = max(0, min(100, base_score))

            # Mock confidence (higher for clearer cases)
            if priority == "HIGH" and variance > 15:
                confidence = 0.9 + np.random.uniform(0, 0.08)
            elif priority == "LOW" and variance < 3:
                confidence = 0.85 + np.random.uniform(0, 0.1)
            else:
                confidence = 0.65 + np.random.uniform(0, 0.2)

            results.append({
                'sku_id': row['sku_id'],
                'recount_priority': priority,
                'urgency_score': round(urgency_score, 1),
                'confidence': round(confidence, 3)
            })

        return pd.DataFrame(results)


class RPTClient:
    """
    Client for SAP-RPT predictions via AI Core SDK.
    """

    def __init__(self):
        self._mock_scorer = MockRPTScorer()
        self._is_live = False
        self._last_check_time = None
        self._check_interval = 60
        self._token = None
        self._token_expires = 0
        self._http_client = None

    def _get_token(self) -> Optional[str]:
        """Get OAuth token for AI Core."""
        creds = get_aicore_credentials()
        if not creds:
            return None

        # Check if token is still valid
        if self._token and time.time() < self._token_expires - 60:
            return self._token

        try:
            auth_url = creds['auth_url'].rstrip('/') + '/oauth/token'
            response = httpx.post(
                auth_url,
                data={
                    'grant_type': 'client_credentials',
                    'client_id': creds['client_id'],
                    'client_secret': creds['client_secret'],
                },
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                timeout=30.0
            )
            response.raise_for_status()
            data = response.json()
            self._token = data['access_token']
            self._token_expires = time.time() + data.get('expires_in', 3600)
            return self._token
        except Exception as e:
            logger.error(f"Failed to get AI Core token: {e}")
            return None

    def _init_client(self) -> bool:
        """Initialize the RPT client if credentials are available."""
        if not is_aicore_configured():
            return False

        settings = get_settings()
        if not settings.rpt_deployment_id:
            logger.warning("⚠️ RPT_DEPLOYMENT_ID not configured")
            return False

        token = self._get_token()
        if not token:
            return False

        self._is_live = True
        logger.info("✅ SAP-RPT client initialized successfully (AI Core SDK)")
        return True

    def is_live(self) -> bool:
        """Check if using live AI Core or mock mode."""
        now = time.time()
        if self._last_check_time is None or (now - self._last_check_time) > self._check_interval:
            self._last_check_time = now
            if not self._is_live:
                self._init_client()
        return self._is_live

    def _chunk_dataframe(self, df: pd.DataFrame) -> list:
        """Split DataFrame into chunks respecting RPT limits."""
        chunks = []
        for i in range(0, len(df), MAX_ROWS_PER_REQUEST):
            chunks.append(df.iloc[i:i + MAX_ROWS_PER_REQUEST])
        return chunks

    def _call_rpt(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Call SAP-RPT for predictions via AI Core inference API.
        """
        settings = get_settings()
        creds = get_aicore_credentials()
        token = self._get_token()

        if not token or not creds:
            raise Exception("No valid token or credentials")

        # Prepare the RPT request body
        n = len(df)

        # Add some labeled examples for in-context learning
        # HIGH examples (high variance, worsening trend)
        example_rows = {
            "SKU_ID": ["EX-HIGH-1", "EX-HIGH-2", "EX-MED-1", "EX-LOW-1", "EX-LOW-2"],
            "CATEGORY": ["Electronics", "Apparel", "Grocery", "Hardware", "Electronics"],
            "AVG_VARIANCE_PCT": [18.5, 12.3, 6.2, 1.5, 0.8],
            "RECOUNT_FREQUENCY_7D": [3, 2, 2, 1, 1],
            "DAYS_SINCE_LAST_COUNT": [2, 5, 4, 7, 3],
            "VARIANCE_TREND": ["worsening", "worsening", "stable", "stable", "improving"],
            "recount_priority": ["HIGH", "HIGH", "MEDIUM", "LOW", "LOW"],
            "urgency_score": [92.0, 78.0, 52.0, 18.0, 12.0],
        }

        # Combine examples with prediction rows
        all_sku_ids = example_rows["SKU_ID"] + df['sku_id'].tolist()
        all_categories = example_rows["CATEGORY"] + df['category'].tolist()
        all_variance = example_rows["AVG_VARIANCE_PCT"] + df['avg_variance_pct'].tolist()
        all_freq = example_rows["RECOUNT_FREQUENCY_7D"] + df['recount_frequency_7d'].tolist()
        all_days = example_rows["DAYS_SINCE_LAST_COUNT"] + df['days_since_last_count'].tolist()
        all_trend = example_rows["VARIANCE_TREND"] + df['variance_trend'].tolist()
        all_priority = example_rows["recount_priority"] + ["[PREDICT]"] * n
        all_score = example_rows["urgency_score"] + ["[PREDICT]"] * n

        request_body = {
            "prediction_config": {
                "target_columns": [
                    {
                        "name": "recount_priority",
                        "prediction_placeholder": "[PREDICT]",
                        "task_type": "classification"
                    },
                    {
                        "name": "urgency_score",
                        "prediction_placeholder": "[PREDICT]",
                        "task_type": "regression"
                    }
                ]
            },
            "columns": {
                "SKU_ID": all_sku_ids,
                "CATEGORY": all_categories,
                "AVG_VARIANCE_PCT": all_variance,
                "RECOUNT_FREQUENCY_7D": all_freq,
                "DAYS_SINCE_LAST_COUNT": all_days,
                "VARIANCE_TREND": all_trend,
                "recount_priority": all_priority,
                "urgency_score": all_score,
            },
            "data_schema": {
                "SKU_ID": {"dtype": "string"},
                "CATEGORY": {"dtype": "string"},
                "AVG_VARIANCE_PCT": {"dtype": "numeric"},
                "RECOUNT_FREQUENCY_7D": {"dtype": "numeric"},
                "DAYS_SINCE_LAST_COUNT": {"dtype": "numeric"},
                "VARIANCE_TREND": {"dtype": "string"},
                "recount_priority": {"dtype": "string"},
                "urgency_score": {"dtype": "numeric"},
            }
        }

        # Call AI Core inference endpoint
        base_url = creds['base_url'].rstrip('/')
        deployment_id = settings.rpt_deployment_id
        url = f"{base_url}/v2/inference/deployments/{deployment_id}/predict"

        logger.info(f"Calling SAP-RPT at {url}")

        response = httpx.post(
            url,
            json=request_body,
            headers={
                'Authorization': f'Bearer {token}',
                'AI-Resource-Group': creds['resource_group'],
                'Content-Type': 'application/json',
            },
            timeout=120.0
        )

        if response.status_code != 200:
            logger.error(f"RPT API error: {response.status_code} - {response.text}")
            response.raise_for_status()

        result = response.json()
        logger.info(f"SAP-RPT response received: {result.get('status', {})}")

        # Parse response - RPT returns predictions array
        # Format: {"predictions": [{"recount_priority": [{"prediction": "HIGH", "confidence": 0.85}], "urgency_score": [{"prediction": 75.0}]}]}
        predictions_list = []
        rpt_predictions = result.get('predictions', [])

        num_examples = len(example_rows["SKU_ID"])

        for i, sku_id in enumerate(df['sku_id']):
            pred_idx = i  # Index in predictions array (predictions only for [PREDICT] rows)

            priority = "MEDIUM"
            score = 50.0
            confidence = 0.75

            if pred_idx < len(rpt_predictions):
                pred = rpt_predictions[pred_idx]

                # Get priority prediction
                priority_preds = pred.get('recount_priority', [])
                if priority_preds and len(priority_preds) > 0:
                    priority = priority_preds[0].get('prediction', 'MEDIUM')
                    confidence = priority_preds[0].get('confidence', 0.75)

                # Get urgency score prediction
                score_preds = pred.get('urgency_score', [])
                if score_preds and len(score_preds) > 0:
                    score = score_preds[0].get('prediction', 50.0)

            # Normalize priority
            if isinstance(priority, str):
                priority = priority.upper()
            else:
                priority = "MEDIUM"

            if priority not in ["HIGH", "MEDIUM", "LOW"]:
                priority = "MEDIUM"

            # Handle score
            try:
                score = float(score)
            except (ValueError, TypeError):
                score = 50.0

            predictions_list.append({
                'sku_id': sku_id,
                'recount_priority': priority,
                'urgency_score': round(score, 1),
                'confidence': round(confidence, 3)
            })

        return pd.DataFrame(predictions_list)

    def predict(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, bool]:
        """
        Get predictions for SKU feature table.

        Returns:
            Tuple of (predictions DataFrame, is_mock bool)
        """
        if df.empty:
            return pd.DataFrame(columns=['sku_id', 'recount_priority', 'urgency_score', 'confidence']), True

        # Check if we can use live client
        if self.is_live():
            try:
                # Chunk if necessary
                chunks = self._chunk_dataframe(df)
                all_predictions = []

                for chunk in chunks:
                    chunk_preds = self._call_rpt(chunk)
                    all_predictions.append(chunk_preds)

                result = pd.concat(all_predictions, ignore_index=True)
                logger.info(f"✅ SAP-RPT predictions complete: {len(result)} SKUs")
                return result, False

            except Exception as e:
                logger.error(f"❌ RPT prediction failed, falling back to mock: {e}")
                # Fall through to mock

        # Use mock scorer
        return self._mock_scorer.predict(df), True


# Singleton instance
_rpt_client: Optional[RPTClient] = None


def get_rpt_client() -> RPTClient:
    """Get or create the RPT client singleton."""
    global _rpt_client
    if _rpt_client is None:
        _rpt_client = RPTClient()
    return _rpt_client


def predict_recount_priorities(df: pd.DataFrame) -> Tuple[pd.DataFrame, bool, float]:
    """
    Main interface for getting recount priority predictions.

    Args:
        df: Feature DataFrame with columns:
            - sku_id, category, avg_variance_pct, recount_frequency_7d,
              days_since_last_count, variance_trend

    Returns:
        Tuple of (predictions DataFrame, is_mock bool, duration_ms)
    """
    start_time = time.time()
    client = get_rpt_client()
    predictions, is_mock = client.predict(df)
    duration_ms = (time.time() - start_time) * 1000
    return predictions, is_mock, duration_ms


def save_predictions_to_cache(predictions: pd.DataFrame, is_mock: bool):
    """Save predictions to database cache."""
    if predictions.empty:
        return

    with get_db() as conn:
        cursor = conn.cursor()

        # Clear old cache
        cursor.execute("DELETE FROM predictions_cache")

        # Insert new predictions
        for _, row in predictions.iterrows():
            cursor.execute("""
                INSERT OR REPLACE INTO predictions_cache
                (sku_id, recount_priority, urgency_score, confidence, is_mock, predicted_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, [
                row['sku_id'],
                row['recount_priority'],
                row['urgency_score'],
                row['confidence'],
                1 if is_mock else 0,
                datetime.now().isoformat()
            ])

        conn.commit()


def load_predictions_from_cache() -> Tuple[Optional[pd.DataFrame], bool, Optional[datetime]]:
    """
    Load predictions from cache if valid.

    Returns:
        Tuple of (predictions DataFrame or None, is_mock, last_predicted_at)
    """
    settings = get_settings()

    with get_db() as conn:
        # Check cache age
        cursor = conn.cursor()
        cursor.execute("SELECT MAX(predicted_at) FROM predictions_cache")
        result = cursor.fetchone()

        if not result or not result[0]:
            return None, True, None

        last_predicted = datetime.fromisoformat(result[0])
        age_seconds = (datetime.now() - last_predicted).total_seconds()

        if age_seconds > settings.prediction_cache_ttl_seconds:
            return None, True, last_predicted

        # Load cached predictions
        df = pd.read_sql_query("""
            SELECT sku_id, recount_priority, urgency_score, confidence, is_mock
            FROM predictions_cache
        """, conn)

        is_mock = df['is_mock'].iloc[0] == 1 if not df.empty else True
        df = df.drop(columns=['is_mock'])

        return df, is_mock, last_predicted


def check_aicore_reachable() -> bool:
    """Check if AI Core is reachable."""
    client = get_rpt_client()
    return client.is_live()
