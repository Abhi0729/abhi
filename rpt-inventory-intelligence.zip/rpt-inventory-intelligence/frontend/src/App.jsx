import { useState, useEffect } from 'react';
import KpiRow from './components/KpiRow';
import RecountList from './components/RecountList';
import SkuDetailDrawer from './components/SkuDetailDrawer';
import Toast from './components/Toast';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import { getHealth, getKpis, rescorePriorities, getSkus } from './api';

export default function App() {
  const [health, setHealth] = useState(null);
  const [kpis, setKpis] = useState({});
  const [loadingKpis, setLoadingKpis] = useState(true);
  const [selectedSku, setSelectedSku] = useState(null);
  const [rescoring, setRescoring] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [error, setError] = useState(null);
  const [toast, setToast] = useState(null);
  const [showAnalytics, setShowAnalytics] = useState(false);

  // Show toast notification
  const showToast = (message, type = 'success', duration = 4000) => {
    setToast({ message, type });
    setTimeout(() => setToast(null), duration);
  };

  // Load health status
  useEffect(() => {
    getHealth()
      .then((data) => {
        setHealth(data);
        if (data.rpt_mode === 'live') {
          showToast('Connected to SAP AI Core', 'success');
        }
      })
      .catch((err) => {
        console.error('Health check failed:', err);
        setHealth({ rpt_mode: 'mock', ai_core_reachable: false });
        showToast('Running in Mock Mode', 'info');
      });
  }, []);

  // Load KPIs
  useEffect(() => {
    setLoadingKpis(true);
    getKpis()
      .then(setKpis)
      .catch((err) => {
        console.error('KPIs failed:', err);
        setError(err.message);
      })
      .finally(() => setLoadingKpis(false));
  }, [refreshKey]);

  // Handle rescore
  const handleRescore = async () => {
    setRescoring(true);
    setError(null);
    const startTime = Date.now();

    try {
      const result = await rescorePriorities(true);
      const duration = ((Date.now() - startTime) / 1000).toFixed(1);
      console.log('Rescore result:', result);
      setRefreshKey((k) => k + 1);
      showToast(`SAP-RPT scored ${result.total_scored || 120} SKUs in ${duration}s`, 'success');
    } catch (err) {
      setError(`Rescore failed: ${err.message}`);
      showToast('Scoring failed. Please try again.', 'error');
    } finally {
      setRescoring(false);
    }
  };

  // Export PDF Report
  const handleExportReport = async () => {
    showToast('Generating PDF report...', 'info');

    try {
      const data = await getSkus({ priority: 'HIGH', page_size: 50 });
      const highRiskSkus = data.items || [];

      // Create printable report
      const reportWindow = window.open('', '_blank');
      reportWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Physical Inventory Intelligence Report</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 40px; color: #1F2937; }
            h1 { color: #0F3A5F; border-bottom: 3px solid #1C7293; padding-bottom: 10px; }
            h2 { color: #0F3A5F; margin-top: 30px; }
            .header-info { display: flex; justify-content: space-between; margin-bottom: 30px; }
            .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 20px 0; }
            .kpi-box { background: #F7F9FC; padding: 20px; border-radius: 8px; text-align: center; border-left: 4px solid #1C7293; }
            .kpi-value { font-size: 28px; font-weight: bold; color: #0F3A5F; }
            .kpi-label { font-size: 12px; color: #6B7280; text-transform: uppercase; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { padding: 12px; text-align: left; border-bottom: 1px solid #E5E7EB; }
            th { background: #F7F9FC; font-size: 12px; text-transform: uppercase; color: #6B7280; }
            .priority-high { background: #FEE2E2; color: #DC2626; padding: 4px 8px; border-radius: 4px; font-weight: 600; font-size: 12px; }
            .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #E5E7EB; font-size: 12px; color: #6B7280; }
            @media print { body { padding: 20px; } }
          </style>
        </head>
        <body>
          <div class="header-info">
            <div>
              <h1>Physical Inventory Intelligence Report</h1>
              <p>AI-Powered Recount Priority Analysis</p>
            </div>
            <div style="text-align: right;">
              <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>
              <p><strong>Mode:</strong> ${health?.rpt_mode === 'live' ? 'SAP-RPT Live' : 'Mock Mode'}</p>
            </div>
          </div>

          <h2>Executive Summary</h2>
          <div class="kpi-grid">
            <div class="kpi-box">
              <div class="kpi-value">${kpis.total_pids?.toLocaleString() || '0'}</div>
              <div class="kpi-label">Total PIDs</div>
            </div>
            <div class="kpi-box" style="border-left-color: #DC2626;">
              <div class="kpi-value" style="color: #DC2626;">${kpis.high_risk_skus || '0'}</div>
              <div class="kpi-label">High-Risk SKUs</div>
            </div>
            <div class="kpi-box" style="border-left-color: #10B981;">
              <div class="kpi-value">${kpis.predictions_today || '0'}</div>
              <div class="kpi-label">Predictions Today</div>
            </div>
            <div class="kpi-box" style="border-left-color: #8B5CF6;">
              <div class="kpi-value">${kpis.avg_confidence ? (kpis.avg_confidence * 100).toFixed(0) + '%' : '--'}</div>
              <div class="kpi-label">Avg Confidence</div>
            </div>
          </div>

          <h2>High-Risk SKUs Requiring Immediate Attention</h2>
          <table>
            <thead>
              <tr>
                <th>SKU</th>
                <th>Description</th>
                <th>Priority</th>
                <th>Urgency</th>
                <th>Variance %</th>
                <th>Trend</th>
                <th>Source</th>
              </tr>
            </thead>
            <tbody>
              ${highRiskSkus.map(sku => `
                <tr>
                  <td><strong>${sku.sku_id}</strong></td>
                  <td>${sku.description}</td>
                  <td><span class="priority-high">${sku.recount_priority}</span></td>
                  <td>${sku.urgency_score?.toFixed(0) || '-'}</td>
                  <td>${sku.avg_variance_pct?.toFixed(1)}%</td>
                  <td>${sku.variance_trend}</td>
                  <td>${sku.source_system}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div class="footer">
            <p><strong>Physical Inventory Intelligence</strong> - Powered by SAP-RPT (Zero-Shot Classification & Regression) + Claude AI (Deep Analysis)</p>
            <p>This report was automatically generated. For detailed SKU analysis, use the interactive dashboard.</p>
          </div>

          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
        </html>
      `);
      reportWindow.document.close();
      showToast('Report generated! Print dialog opened.', 'success');
    } catch (err) {
      showToast('Failed to generate report', 'error');
    }
  };

  const isLive = health?.rpt_mode === 'live';

  return (
    <div className="app">
      {/* Toast Notifications */}
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Header */}
      <header className="header">
        <h1>
          <svg
            className="header-logo"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2" />
            <rect x="9" y="3" width="6" height="4" rx="1" />
            <path d="M9 14l2 2 4-4" />
          </svg>
          Physical Inventory Intelligence
        </h1>

        <div className="header-actions">
          {/* Analytics Button */}
          <button className="btn btn-analytics" onClick={() => setShowAnalytics(true)}>
            📊 Analytics
          </button>

          {/* Export Report Button */}
          <button className="btn btn-secondary" onClick={handleExportReport}>
            📄 Export Report
          </button>

          {/* Rescore Button */}
          <button
            className="btn btn-primary"
            onClick={handleRescore}
            disabled={rescoring}
          >
            {rescoring ? (
              <>
                <div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} />
                Scoring...
              </>
            ) : (
              <>Re-score with SAP-RPT</>
            )}
          </button>

          {/* Status Pill */}
          <div className={`status-pill ${isLive ? 'live' : 'mock'}`}>
            <div className="status-dot" />
            {isLive ? 'SAP-RPT Live' : 'Mock Mode'}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        {/* Error Banner */}
        {error && (
          <div className="error" style={{ marginBottom: '24px' }}>
            {error}
            <button
              style={{
                marginLeft: '16px',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                fontWeight: 'bold',
              }}
              onClick={() => setError(null)}
            >
              Dismiss
            </button>
          </div>
        )}

        {/* KPIs */}
        <KpiRow kpis={kpis} loading={loadingKpis} />

        {/* Dashboard Grid */}
        <div className="dashboard-grid">
          <RecountList
            onSelectSku={setSelectedSku}
            refresh={refreshKey}
          />
        </div>
      </main>

      {/* Detail Drawer */}
      {selectedSku && (
        <SkuDetailDrawer
          skuId={selectedSku}
          onClose={() => setSelectedSku(null)}
        />
      )}

      {/* Analytics Dashboard Modal */}
      {showAnalytics && (
        <AnalyticsDashboard onClose={() => setShowAnalytics(false)} />
      )}
    </div>
  );
}
