import { useState, useEffect } from 'react';
import KpiRow from './components/KpiRow';
import RecountList from './components/RecountList';
import SkuDetailDrawer from './components/SkuDetailDrawer';
import { getHealth, getKpis, rescorePriorities } from './api';

export default function App() {
  const [health, setHealth] = useState(null);
  const [kpis, setKpis] = useState({});
  const [loadingKpis, setLoadingKpis] = useState(true);
  const [selectedSku, setSelectedSku] = useState(null);
  const [rescoring, setRescoring] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [error, setError] = useState(null);

  // Load health status
  useEffect(() => {
    getHealth()
      .then(setHealth)
      .catch((err) => {
        console.error('Health check failed:', err);
        setHealth({ rpt_mode: 'mock', ai_core_reachable: false });
      });
  }, []);

  // Load KPIs
  useEffect(() => {
    setLoadingKpis(true);
    getKpis()
      .then(setKpis)
      .catch((err) => {
        console.error('KPIs failed:', err);
        setError(err.message);
      })
      .finally(() => setLoadingKpis(false));
  }, [refreshKey]);

  // Handle rescore
  const handleRescore = async () => {
    setRescoring(true);
    setError(null);

    try {
      const result = await rescorePriorities(true);
      console.log('Rescore result:', result);
      setRefreshKey((k) => k + 1);
    } catch (err) {
      setError(`Rescore failed: ${err.message}`);
    } finally {
      setRescoring(false);
    }
  };

  const isLive = health?.rpt_mode === 'live';

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <h1>
          <svg
            className="header-logo"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2" />
            <rect x="9" y="3" width="6" height="4" rx="1" />
            <path d="M9 14l2 2 4-4" />
          </svg>
          Physical Inventory Intelligence
        </h1>

        <div className="header-actions">
          {/* Rescore Button */}
          <button
            className="btn btn-primary"
            onClick={handleRescore}
            disabled={rescoring}
          >
            {rescoring ? (
              <>
                <div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} />
                Scoring...
              </>
            ) : (
              <>Re-score with SAP-RPT</>
            )}
          </button>

          {/* Status Pill */}
          <div className={`status-pill ${isLive ? 'live' : 'mock'}`}>
            <div className="status-dot" />
            {isLive ? 'SAP-RPT Live' : 'Mock Mode'}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        {/* Error Banner */}
        {error && (
          <div className="error" style={{ marginBottom: '24px' }}>
            {error}
            <button
              style={{
                marginLeft: '16px',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                fontWeight: 'bold',
              }}
              onClick={() => setError(null)}
            >
              Dismiss
            </button>
          </div>
        )}

        {/* KPIs */}
        <KpiRow kpis={kpis} loading={loadingKpis} />

        {/* Dashboard Grid */}
        <div className="dashboard-grid">
          <RecountList
            onSelectSku={setSelectedSku}
            refresh={refreshKey}
          />
        </div>
      </main>

      {/* Detail Drawer */}
      {selectedSku && (
        <SkuDetailDrawer
          skuId={selectedSku}
          onClose={() => setSelectedSku(null)}
        />
      )}
    </div>
  );
}
