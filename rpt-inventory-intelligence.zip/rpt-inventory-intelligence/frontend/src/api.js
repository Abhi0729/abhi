/**
 * API client for Physical Inventory Intelligence backend
 */

// Dynamically derive backend URL from frontend URL
function getApiBase() {
  if (import.meta.env.DEV) {
    return '/api'; // Vite proxy in development
  }

  // Production: derive backend URL from current hostname
  // rpt-inventory-frontend.cfapps.xxx -> rpt-inventory-backend.cfapps.xxx
  const hostname = window.location.hostname;
  const backendHost = hostname.replace('-frontend', '-backend');
  return `https://${backendHost}/api`;
}

const API_BASE = getApiBase();

async function fetchJson(url, options = {}) {
  const response = await fetch(`${API_BASE}${url}`, {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  });

  if (!response.ok) {
    const error = new Error(`HTTP ${response.status}: ${response.statusText}`);
    error.status = response.status;
    throw error;
  }

  return response.json();
}

export async function getHealth() {
  return fetchJson('/health');
}

export async function getKpis() {
  return fetchJson('/kpis');
}

export async function getSkus(params = {}) {
  const searchParams = new URLSearchParams();

  if (params.priority) searchParams.set('priority', params.priority);
  if (params.source) searchParams.set('source', params.source);
  if (params.category) searchParams.set('category', params.category);
  if (params.search) searchParams.set('search', params.search);
  if (params.page) searchParams.set('page', params.page);
  if (params.page_size) searchParams.set('page_size', params.page_size);

  const queryString = searchParams.toString();
  return fetchJson(`/skus${queryString ? `?${queryString}` : ''}`);
}

export async function getSkuDetail(skuId) {
  return fetchJson(`/skus/${skuId}`);
}

export async function getCategories() {
  return fetchJson('/skus/categories');
}

export async function rescorePriorities(force = false) {
  return fetchJson('/recounts/rescore', {
    method: 'POST',
    body: JSON.stringify({ force }),
  });
}

/**
 * Get deep AI analysis for a specific SKU using GPT.
 * This is the HYBRID AI feature - GPT provides detailed analysis
 * while SAP-RPT handles bulk scoring.
 */
export async function getDeepAnalysis(skuId) {
  return fetchJson(`/skus/${skuId}/analysis`, {
    method: 'POST',
  });
}

/**
 * Check if GPT deep analysis is available.
 */
export async function getAnalysisStatus() {
  return fetchJson('/skus/analysis/status');
}
