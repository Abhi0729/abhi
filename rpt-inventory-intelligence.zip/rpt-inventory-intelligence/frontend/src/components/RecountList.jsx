import { useState, useEffect, useRef } from 'react';
import SourceBadge from './SourceBadge';
import { getSkus, getCategories } from '../api';

/**
 * Priority Badge component
 */
function PriorityBadge({ priority }) {
  if (!priority) return <span className="priority-badge">--</span>;

  const level = priority.toLowerCase();
  return <span className={`priority-badge ${level}`}>{priority}</span>;
}

/**
 * Urgency Score Bar
 */
function UrgencyBar({ score }) {
  if (score === null || score === undefined) return <span>--</span>;

  const level = score >= 70 ? 'high' : score >= 40 ? 'medium' : 'low';

  return (
    <div className="urgency-bar">
      <div className="urgency-track">
        <div
          className={`urgency-fill ${level}`}
          style={{ width: `${score}%` }}
        />
      </div>
      <span>{score.toFixed(0)}</span>
    </div>
  );
}

/**
 * Trend Indicator
 */
function TrendIndicator({ trend }) {
  const arrows = {
    worsening: '↑',
    improving: '↓',
    stable: '→',
  };

  return (
    <span className={`trend ${trend || 'stable'}`}>
      {arrows[trend] || '→'} {trend || 'stable'}
    </span>
  );
}

/**
 * Recount List - Main table showing ranked SKUs
 */
export default function RecountList({ onSelectSku, refresh }) {
  const [skus, setSkus] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [categories, setCategories] = useState([]);
  const [highlightHigh, setHighlightHigh] = useState(false);
  const initialLoadRef = useRef(true);

  // Filters
  const [filters, setFilters] = useState({
    priority: '',
    source: '',
    category: '',
    search: '',
  });

  // Pagination
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const pageSize = 15;

  // Load categories on mount
  useEffect(() => {
    getCategories()
      .then(setCategories)
      .catch(console.error);
  }, []);

  // Load SKUs when filters or page changes
  useEffect(() => {
    setLoading(true);
    setError(null);

    getSkus({
      priority: filters.priority,
      source: filters.source,
      category: filters.category,
      search: filters.search,
      page,
      page_size: pageSize,
    })
      .then((data) => {
        setSkus(data.items || []);
        setTotalPages(data.total_pages || 1);
        setTotal(data.total || 0);
      })
      .catch((err) => {
        setError(err.message);
        setSkus([]);
      })
      .finally(() => setLoading(false));
  }, [filters, page, refresh]);

  // Enable HIGH priority highlighting after rescore (skip initial load)
  useEffect(() => {
    if (initialLoadRef.current) {
      initialLoadRef.current = false;
      return;
    }
    if (refresh > 0) {
      setHighlightHigh(true);
    }
  }, [refresh]);

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
    setPage(1); // Reset to first page on filter change
  };

  return (
    <div className="card">
      <div className="card-header">
        <h2>Recount Priority List</h2>
        <span style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
          {total} SKUs total
        </span>
      </div>

      {/* Filters */}
      <div className="card-body" style={{ paddingBottom: 0 }}>
        <div className="filters">
          <select
            className="filter-select"
            value={filters.priority}
            onChange={(e) => handleFilterChange('priority', e.target.value)}
          >
            <option value="">All Priorities</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>

          <select
            className="filter-select"
            value={filters.source}
            onChange={(e) => handleFilterChange('source', e.target.value)}
          >
            <option value="">All Sources</option>
            <option value="ECC">ECC</option>
            <option value="S4HANA">S/4HANA</option>
          </select>

          <select
            className="filter-select"
            value={filters.category}
            onChange={(e) => handleFilterChange('category', e.target.value)}
          >
            <option value="">All Categories</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          <input
            type="text"
            className="filter-input"
            placeholder="Search SKU or description..."
            value={filters.search}
            onChange={(e) => handleFilterChange('search', e.target.value)}
          />
        </div>
      </div>

      {/* Error State */}
      {error && <div className="error">{error}</div>}

      {/* Loading State */}
      {loading && (
        <div className="loading">
          <div className="spinner" />
          Loading SKUs...
        </div>
      )}

      {/* Table */}
      {!loading && !error && (
        <>
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>SKU</th>
                  <th>Description</th>
                  <th>Priority</th>
                  <th>Urgency</th>
                  <th>Variance %</th>
                  <th>Trend</th>
                  <th>Source</th>
                </tr>
              </thead>
              <tbody>
                {skus.map((sku) => {
                  const isHighPriority = highlightHigh && sku.recount_priority === 'HIGH';
                  return (
                    <tr
                      key={sku.sku_id}
                      onClick={() => onSelectSku(sku.sku_id)}
                      className={isHighPriority ? 'row-changed' : ''}
                    >
                      <td style={{ fontWeight: 500 }}>{sku.sku_id}</td>
                      <td>
                        <div>{sku.description}</div>
                        <div className="explanation">{sku.explanation}</div>
                      </td>
                      <td>
                        <PriorityBadge priority={sku.recount_priority} />
                      </td>
                      <td>
                        <UrgencyBar score={sku.urgency_score} />
                      </td>
                      <td>
                        {sku.avg_variance_pct?.toFixed(1) || '0.0'}%
                      </td>
                      <td>
                        <TrendIndicator trend={sku.variance_trend} />
                      </td>
                      <td>
                        <SourceBadge source={sku.source_system} />
                      </td>
                    </tr>
                  );
                })}
                {skus.length === 0 && (
                  <tr>
                    <td colSpan={7} style={{ textAlign: 'center', color: 'var(--text-secondary)' }}>
                      No SKUs found matching your filters
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="pagination">
            <span className="pagination-info">
              Page {page} of {totalPages}
            </span>
            <div className="pagination-buttons">
              <button
                className="btn btn-secondary"
                disabled={page <= 1}
                onClick={() => setPage((p) => p - 1)}
              >
                Previous
              </button>
              <button
                className="btn btn-secondary"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                Next
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
