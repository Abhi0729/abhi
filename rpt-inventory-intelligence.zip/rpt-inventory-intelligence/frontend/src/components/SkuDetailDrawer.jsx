import { useState, useEffect } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import SourceBadge from './SourceBadge';
import { getSkuDetail } from '../api';

/**
 * SKU Detail Drawer - Shows detailed info and 60-day history chart
 */
export default function SkuDetailDrawer({ skuId, onClose }) {
  const [sku, setSku] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!skuId) return;

    setLoading(true);
    setError(null);

    getSkuDetail(skuId)
      .then(setSku)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [skuId]);

  if (!skuId) return null;

  // Prepare chart data
  const chartData = sku?.history
    ?.slice()
    .reverse()
    .map((pid) => ({
      date: new Date(pid.count_date).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
      }),
      book_qty: pid.book_qty,
      counted_qty: pid.counted_qty,
      variance: pid.variance_pct,
    })) || [];

  return (
    <>
      <div className="drawer-overlay" onClick={onClose} />
      <div className="drawer">
        <div className="drawer-header">
          <h2>{skuId}</h2>
          <button className="drawer-close" onClick={onClose}>
            &times;
          </button>
        </div>

        <div className="drawer-body">
          {loading && (
            <div className="loading">
              <div className="spinner" />
              Loading details...
            </div>
          )}

          {error && <div className="error">{error}</div>}

          {!loading && !error && sku && (
            <>
              {/* SKU Info */}
              <div className="detail-section">
                <h3>SKU Information</h3>
                <div className="detail-grid">
                  <div className="detail-item">
                    <span className="label">Description</span>
                    <span className="value">{sku.description}</span>
                  </div>
                  <div className="detail-item">
                    <span className="label">Category</span>
                    <span className="value">{sku.category}</span>
                  </div>
                  <div className="detail-item">
                    <span className="label">Plant</span>
                    <span className="value">{sku.plant}</span>
                  </div>
                  <div className="detail-item">
                    <span className="label">Source System</span>
                    <span className="value">
                      <SourceBadge source={sku.source_system} />
                    </span>
                  </div>
                  <div className="detail-item">
                    <span className="label">Unit Cost</span>
                    <span className="value">${sku.unit_cost?.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Prediction */}
              <div className="detail-section">
                <h3>RPT Prediction</h3>
                <div className="detail-grid">
                  <div className="detail-item">
                    <span className="label">Priority</span>
                    <span className="value">
                      <span
                        className={`priority-badge ${sku.recount_priority?.toLowerCase() || ''}`}
                      >
                        {sku.recount_priority || 'N/A'}
                      </span>
                    </span>
                  </div>
                  <div className="detail-item">
                    <span className="label">Urgency Score</span>
                    <span className="value">
                      {sku.urgency_score?.toFixed(1) || 'N/A'}
                    </span>
                  </div>
                  <div className="detail-item">
                    <span className="label">Confidence</span>
                    <span className="value">
                      {sku.confidence
                        ? `${(sku.confidence * 100).toFixed(0)}%`
                        : 'N/A'}
                    </span>
                  </div>
                  <div className="detail-item">
                    <span className="label">Mode</span>
                    <span className="value">
                      {sku.is_mock ? 'Mock Scorer' : 'SAP-RPT'}
                    </span>
                  </div>
                </div>
                {sku.explanation && (
                  <p className="explanation" style={{ marginTop: '12px' }}>
                    {sku.explanation}
                  </p>
                )}
              </div>

              {/* Feature Values */}
              <div className="detail-section">
                <h3>Feature Values (Sent to RPT)</h3>
                <div className="detail-grid">
                  <div className="detail-item">
                    <span className="label">Avg Variance (14d)</span>
                    <span className="value">
                      {sku.avg_variance_pct?.toFixed(2)}%
                    </span>
                  </div>
                  <div className="detail-item">
                    <span className="label">Recount Freq (7d)</span>
                    <span className="value">{sku.recount_frequency_7d}</span>
                  </div>
                  <div className="detail-item">
                    <span className="label">Days Since Last Count</span>
                    <span className="value">{sku.days_since_last_count}</span>
                  </div>
                  <div className="detail-item">
                    <span className="label">Variance Trend</span>
                    <span className={`trend ${sku.variance_trend || 'stable'}`}>
                      {sku.variance_trend || 'stable'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Chart */}
              <div className="detail-section">
                <h3>60-Day Inventory History</h3>
                <div className="chart-container">
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                      <XAxis
                        dataKey="date"
                        tick={{ fontSize: 12 }}
                        tickMargin={8}
                      />
                      <YAxis tick={{ fontSize: 12 }} tickMargin={8} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#fff',
                          border: '1px solid #E5E7EB',
                          borderRadius: '8px',
                        }}
                      />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="book_qty"
                        name="Book Qty"
                        stroke="#0F3A5F"
                        strokeWidth={2}
                        dot={false}
                      />
                      <Line
                        type="monotone"
                        dataKey="counted_qty"
                        name="Counted Qty"
                        stroke="#1C7293"
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Recent Counts */}
              <div className="detail-section">
                <h3>Recent Counts</h3>
                <div className="table-container">
                  <table>
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Book Qty</th>
                        <th>Counted</th>
                        <th>Variance</th>
                        <th>Counted By</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sku.history?.slice(0, 10).map((pid) => (
                        <tr key={pid.pid_id}>
                          <td>
                            {new Date(pid.count_date).toLocaleDateString()}
                          </td>
                          <td>{pid.book_qty}</td>
                          <td>{pid.counted_qty}</td>
                          <td
                            style={{
                              color:
                                Math.abs(pid.variance_pct) > 10
                                  ? 'var(--priority-high)'
                                  : Math.abs(pid.variance_pct) > 5
                                  ? 'var(--priority-medium)'
                                  : 'inherit',
                            }}
                          >
                            {pid.variance_pct?.toFixed(1)}%
                          </td>
                          <td>{pid.counted_by}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}
