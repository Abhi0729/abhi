import { useState, useEffect } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import SourceBadge from './SourceBadge';
import { getSkuDetail, getDeepAnalysis } from '../api';

export default function SkuDetailDrawer({ skuId, onClose }) {
  const [sku, setSku] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [analysisError, setAnalysisError] = useState(null);

  useEffect(() => {
    if (!skuId) return;
    setLoading(true);
    setError(null);
    setAnalysis(null);
    setAnalysisError(null);

    getSkuDetail(skuId)
      .then(setSku)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [skuId]);

  const handleDeepAnalysis = async () => {
    setAnalysisLoading(true);
    setAnalysisError(null);
    try {
      const result = await getDeepAnalysis(skuId);
      setAnalysis(result);
    } catch (err) {
      setAnalysisError(err.message || 'Failed to get analysis');
    } finally {
      setAnalysisLoading(false);
    }
  };

  if (!skuId) return null;

  const chartData = sku?.history?.slice().reverse().map((pid) => ({
    date: new Date(pid.count_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    book: pid.book_qty,
    counted: pid.counted_qty,
    variance: pid.variance_pct,
  })) || [];

  const getRiskColor = (level) => {
    const colors = { critical: '#DC2626', high: '#EA580C', medium: '#F59E0B', low: '#10B981' };
    return colors[level?.toLowerCase()] || '#6B7280';
  };

  const getPriorityStyle = (priority) => {
    const styles = {
      immediate: { bg: '#DC2626', label: 'IMMEDIATE' },
      'short-term': { bg: '#F59E0B', label: 'SHORT-TERM' },
      'long-term': { bg: '#3B82F6', label: 'LONG-TERM' },
    };
    return styles[priority?.toLowerCase()] || { bg: '#6B7280', label: priority };
  };

  return (
    <>
      <div className="drawer-overlay" onClick={onClose} />
      <div className={`drawer ${analysis ? 'drawer-expanded' : ''}`}>
        {/* Header */}
        <div className="drawer-header">
          <div className="drawer-title">
            <h2>{skuId}</h2>
            {sku && <span className="drawer-subtitle">{sku.description}</span>}
          </div>
          <button className="drawer-close" onClick={onClose}>×</button>
        </div>

        <div className="drawer-body">
          {loading && (
            <div className="loading">
              <div className="spinner" />
              Loading details...
            </div>
          )}

          {error && <div className="error">{error}</div>}

          {!loading && !error && sku && (
            <div className={`drawer-layout ${analysis ? 'with-analysis' : ''}`}>
              {/* Left Side - SKU Details */}
              <div className="drawer-details">
                {/* Quick Stats */}
                <div className="quick-stats">
                  <div className="stat-card">
                    <span className="stat-label">Priority</span>
                    <span className={`priority-badge large ${sku.recount_priority?.toLowerCase()}`}>
                      {sku.recount_priority || 'N/A'}
                    </span>
                  </div>
                  <div className="stat-card">
                    <span className="stat-label">Urgency</span>
                    <span className="stat-value">{sku.urgency_score?.toFixed(0) || '—'}</span>
                  </div>
                  <div className="stat-card">
                    <span className="stat-label">ML Score</span>
                    <span className="stat-value">{sku.confidence ? `${(sku.confidence * 100).toFixed(0)}%` : '—'}</span>
                  </div>
                  <div className="stat-card">
                    <span className="stat-label">Variance</span>
                    <span className="stat-value">{sku.avg_variance_pct?.toFixed(1)}%</span>
                  </div>
                  <div className="stat-card">
                    <span className="stat-label">Trend</span>
                    <span className={`trend ${sku.variance_trend}`}>{sku.variance_trend}</span>
                  </div>
                </div>

                {/* SKU Info */}
                <div className="detail-section">
                  <h3>SKU Information</h3>
                  <div className="info-grid">
                    <div className="info-row">
                      <span className="info-label">Category</span>
                      <span className="info-value">{sku.category}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Plant</span>
                      <span className="info-value">{sku.plant}</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Source</span>
                      <span className="info-value"><SourceBadge source={sku.source_system} /></span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Unit Cost</span>
                      <span className="info-value">${sku.unit_cost?.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                {/* Chart */}
                <div className="detail-section">
                  <h3>Inventory History</h3>
                  <div className="chart-wrapper">
                    <ResponsiveContainer width="100%" height={200}>
                      <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                        <XAxis dataKey="date" tick={{ fontSize: 9 }} />
                        <YAxis tick={{ fontSize: 9 }} />
                        <Tooltip />
                        <Line type="monotone" dataKey="book" name="Book" stroke="#0F3A5F" strokeWidth={2} dot={false} />
                        <Line type="monotone" dataKey="counted" name="Counted" stroke="#1C7293" strokeWidth={2} dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Recent Counts Table */}
                {sku.history?.length > 0 && (
                  <div className="detail-section">
                    <h3>Recent Count Records</h3>
                    <div className="history-table-wrapper">
                      <table className="history-table">
                        <thead>
                          <tr>
                            <th>Date</th>
                            <th>Book Qty</th>
                            <th>Counted</th>
                            <th>Variance</th>
                            <th>By</th>
                          </tr>
                        </thead>
                        <tbody>
                          {sku.history.slice(0, 8).map((record, idx) => (
                            <tr key={idx}>
                              <td>{new Date(record.count_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</td>
                              <td>{record.book_qty?.toLocaleString()}</td>
                              <td>{record.counted_qty?.toLocaleString()}</td>
                              <td className={record.variance_pct > 5 ? 'variance-high' : record.variance_pct < -5 ? 'variance-high' : ''}>
                                {record.variance_pct > 0 ? '+' : ''}{record.variance_pct?.toFixed(1)}%
                              </td>
                              <td>{record.counted_by}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Analysis Trigger */}
                {!analysis && !analysisLoading && (
                  <div className="analysis-trigger">
                    <button className="btn-run-analysis" onClick={handleDeepAnalysis}>
                      🔍 Run Deep Analysis
                    </button>
                  </div>
                )}

                {analysisLoading && (
                  <div className="analysis-loading">
                    <div className="spinner" />
                    <span>Analyzing...</span>
                  </div>
                )}

                {analysisError && (
                  <div className="error" style={{ margin: 0 }}>
                    {analysisError}
                  </div>
                )}
              </div>

              {/* Right Side - Analysis Results */}
              {analysis && (
                <div className="drawer-analysis">
                  <div className="analysis-scroll">
                    {/* Header */}
                    <div className="analysis-top">
                      <h3>Deep Analysis</h3>
                      <div className="analysis-meta">
                        <span className="model-badge">{analysis.model_used?.split('--').pop()}</span>
                        <button className="btn-refresh" onClick={handleDeepAnalysis}>↻</button>
                      </div>
                    </div>

                    {/* Problem Summary */}
                    {analysis.problem_summary && (
                      <div className="problem-card">
                        <div className="problem-header">
                          <span className="problem-icon">⚠️</span>
                          <span className="problem-title">Issue Identified</span>
                        </div>
                        <p className="problem-text">{analysis.problem_summary}</p>
                      </div>
                    )}

                    {/* Metrics */}
                    <div className="analysis-metrics">
                      {analysis.risk_level && (
                        <div className="metric-pill">
                          <span className="metric-label">Risk</span>
                          <span className="metric-value" style={{ color: getRiskColor(analysis.risk_level) }}>
                            {analysis.risk_level}
                          </span>
                        </div>
                      )}
                      {analysis.confidence_score && (
                        <div className="metric-pill">
                          <span className="metric-label">Analysis Conf.</span>
                          <span className="metric-value">{analysis.confidence_score}%</span>
                        </div>
                      )}
                      {analysis.financial_impact?.estimated_value_at_risk && (
                        <div className="metric-pill highlight">
                          <span className="metric-label">At Risk</span>
                          <span className="metric-value">{analysis.financial_impact.estimated_value_at_risk}</span>
                        </div>
                      )}
                    </div>

                    {/* Financial Impact Detail */}
                    {analysis.financial_impact?.impact_description && (
                      <div className="financial-impact-card">
                        <span className="financial-icon">💰</span>
                        <p>{analysis.financial_impact.impact_description}</p>
                      </div>
                    )}

                    {/* Root Causes */}
                    {analysis.root_causes?.length > 0 && (
                      <div className="analysis-section">
                        <h4>Root Causes</h4>
                        {analysis.root_causes.map((cause, i) => (
                          <div key={i} className="cause-item">
                            <span className="cause-num">{i + 1}</span>
                            <div className="cause-content">
                              <strong>{cause.cause}</strong>
                              <p>{cause.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Actions */}
                    {analysis.mitigation_actions?.length > 0 && (
                      <div className="analysis-section">
                        <h4>Recommended Actions</h4>
                        {analysis.mitigation_actions.map((action, i) => {
                          const style = getPriorityStyle(action.priority);
                          return (
                            <div key={i} className="action-item">
                              <span className="action-badge" style={{ backgroundColor: style.bg }}>
                                {style.label}
                              </span>
                              <div className="action-content">
                                <strong>{action.action}</strong>
                                <p>{action.description}</p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* Key Insight */}
                    {analysis.key_insight && (
                      <div className="insight-card">
                        <span className="insight-icon">💡</span>
                        <p>{analysis.key_insight}</p>
                      </div>
                    )}

                    <div className="analysis-footer">
                      Generated in {analysis.duration_ms?.toFixed(0)}ms
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
