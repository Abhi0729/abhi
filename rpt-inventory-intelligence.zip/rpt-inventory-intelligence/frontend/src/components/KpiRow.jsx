/**
 * KPI Row - Display key performance indicators
 */
export default function KpiRow({ kpis, loading }) {
  if (loading) {
    return (
      <div className="kpi-row">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="kpi-card">
            <span className="label">Loading...</span>
            <span className="value">--</span>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="kpi-row">
      <div className="kpi-card">
        <span className="label">Total PIDs</span>
        <span className="value">{kpis.total_pids?.toLocaleString() || 0}</span>
      </div>

      <div className="kpi-card highlight">
        <span className="label">High-Risk SKUs</span>
        <span className="value">{kpis.high_risk_skus || 0}</span>
      </div>

      <div className="kpi-card">
        <span className="label">Predictions Today</span>
        <span className="value">{kpis.predictions_today || 0}</span>
      </div>

      <div className="kpi-card">
        <span className="label">Avg Confidence</span>
        <span className="value">
          {kpis.avg_confidence ? `${(kpis.avg_confidence * 100).toFixed(0)}%` : '--'}
        </span>
      </div>
    </div>
  );
}
