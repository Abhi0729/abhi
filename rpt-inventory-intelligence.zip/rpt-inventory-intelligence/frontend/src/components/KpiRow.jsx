/**
 * KPI Row - Display key performance indicators
 */
export default function KpiRow({ kpis, loading }) {
  if (loading) {
    return (
      <div className="kpi-row">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="kpi-card">
            <div className="kpi-content">
              <span className="kpi-label">Loading...</span>
              <span className="kpi-value">--</span>
            </div>
          </div>
        ))}
      </div>
    );
  }

  const kpiData = [
    {
      label: 'Total PIDs',
      value: kpis.total_pids?.toLocaleString() || '0',
      icon: '📋',
      color: 'blue'
    },
    {
      label: 'High-Risk SKUs',
      value: kpis.high_risk_skus || '0',
      icon: '⚠️',
      color: 'red',
      highlight: true
    },
    {
      label: 'Predictions Today',
      value: kpis.predictions_today || '0',
      icon: '🎯',
      color: 'green'
    },
    {
      label: 'Avg Confidence',
      value: kpis.avg_confidence ? `${(kpis.avg_confidence * 100).toFixed(0)}%` : '--',
      icon: '📊',
      color: 'purple'
    }
  ];

  return (
    <div className="kpi-row">
      {kpiData.map((kpi, idx) => (
        <div key={idx} className={`kpi-card ${kpi.highlight ? 'highlight' : ''} kpi-${kpi.color}`}>
          <div className="kpi-icon">{kpi.icon}</div>
          <div className="kpi-content">
            <span className="kpi-value">{kpi.value}</span>
            <span className="kpi-label">{kpi.label}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
