/**
 * Source Badge - Shows ECC or S/4HANA origin
 */
export default function SourceBadge({ source }) {
  const isEcc = source === 'ECC';

  return (
    <span className={`source-badge ${isEcc ? 'ecc' : 's4hana'}`}>
      {isEcc ? 'ECC' : 'S/4HANA'}
    </span>
  );
}
